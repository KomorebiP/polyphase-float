#!/usr/bin/env python3
"""Verify delivered archive bytes and metadata against the frozen source."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import struct
import tarfile
import zipfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("archive_directory", type=Path)
    args = parser.parse_args()
    base = Path(__file__).resolve().parents[1]
    source = base / "work/polyphase-float"
    snapshot_path = base / "qualification/SOURCE_SNAPSHOT_FINAL.json"
    snapshot = json.loads(snapshot_path.read_text())
    epoch = 1792627200
    prefix = "polyphase-float-0.20.0/"
    expected_modes = {}
    for name, digest in snapshot.items():
        data = (source / name).read_bytes()
        assert sha(data) == digest, name
        expected_modes[name] = 0o755 if data.startswith(b"#!") else 0o644
    checksums = {}
    for line in (args.archive_directory / "SHA256SUMS").read_text().splitlines():
        digest, name = line.split()
        assert name == Path(name).name
        checksums[name] = digest
        assert sha((args.archive_directory / name).read_bytes()) == digest, name
    counts = {}
    for suffix in (".tar.gz", ".zip"):
        path = args.archive_directory / (prefix.rstrip("/") + suffix)
        actual = {}
        if suffix == ".tar.gz":
            assert struct.unpack("<I", path.read_bytes()[4:8])[0] == epoch
            with tarfile.open(path) as archive:
                for item in archive.getmembers():
                    assert item.name.startswith(prefix), item.name
                    name = item.name[len(prefix):]
                    assert name not in actual and name in snapshot, name
                    assert item.isfile() and not item.linkname, name
                    assert item.mode == expected_modes[name], name
                    assert (item.uid, item.gid, item.uname, item.gname, item.mtime) == (0, 0, "root", "root", epoch), name
                    actual[name] = sha(archive.extractfile(item).read())
        else:
            with zipfile.ZipFile(path) as archive:
                assert archive.testzip() is None
                for item in archive.infolist():
                    assert item.filename.startswith(prefix), item.filename
                    name = item.filename[len(prefix):]
                    assert name not in actual and name in snapshot, name
                    assert not item.is_dir() and item.create_system == 3, name
                    assert item.external_attr >> 16 == expected_modes[name], name
                    assert item.date_time == (2026, 10, 22, 0, 0, 0), name
                    actual[name] = sha(archive.read(item))
        assert actual == snapshot, suffix
        counts[path.name] = len(actual)
    receipt = {
        "status": "PASS",
        "completed_utc": datetime.now(timezone.utc).isoformat(),
        "source_snapshot_sha256": sha(snapshot_path.read_bytes()),
        "source_file_count": len(snapshot),
        "archive_members": counts,
        "archive_sha256": checksums,
        "checks": ["Every source byte matches frozen snapshot", "No missing, extra or duplicate entries", "No symlinks or nonregular archive entries", "Normalized shebang-based 0755/0644 modes", "Canonical timestamp and tar ownership", "ZIP integrity and published SHA256SUMS"],
        "mode_policy": "Archive modes follow the packager's shebang rule; they need not equal historical Git modes.",
    }
    destination = base / "qualification/ARCHIVE_VERIFICATION_FINAL.json"
    destination.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
