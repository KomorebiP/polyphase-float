#include "polyphase_float.h"
#include <mpfr.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <float.h>
#include <math.h>

static unsigned long cases[6], group_failures[6], failures, decided, undecided;
static const char *names[]={"arithmetic_alias", "binary_conversion", "subnormalize", "exponent_limits", "dyadic_interval", "negative_controls"};
static int signum(int x){return (x>0)-(x<0);}
static int same(mpfr_srcptr a, mpfr_srcptr b){
 if(mpfr_nan_p(a)||mpfr_nan_p(b))return mpfr_nan_p(a)&&mpfr_nan_p(b);
 if(mpfr_inf_p(a)||mpfr_inf_p(b))return mpfr_inf_p(a)&&mpfr_inf_p(b)&&mpfr_signbit(a)==mpfr_signbit(b);
 return mpfr_equal_p(a,b)&&(!mpfr_zero_p(a)||mpfr_signbit(a)==mpfr_signbit(b));
}
static void die(const char *s){fprintf(stderr,"HARNESS ERROR: %s\n",s);exit(2);}
static void export_exact(mpfr_ptr m,const ppf_t *p){
 if(ppf_nan_p(p)){mpfr_set_nan(m);return;}
 if(ppf_inf_p(p)){mpfr_set_inf(m,ppf_signbit(p)?-1:1);return;}
 if(ppf_zero_p(p)){mpfr_set_zero(m,ppf_signbit(p)?-1:1);return;}
 mpz_t z;mpz_init(z);ppf_exp_t e=ppf_get_z_2exp(z,p);
 if(mpfr_set_z_2exp(m,z,(mpfr_exp_t)e,MPFR_RNDN)!=0)die("inexact export");
 mpz_clear(z);
}
static unsigned mflags(void){return (mpfr_underflow_p()?1:0)|(mpfr_overflow_p()?2:0)|(mpfr_divby0_p()?4:0)|(mpfr_nanflag_p()?8:0)|(mpfr_inexflag_p()?16:0)|(mpfr_erangeflag_p()?32:0);}
static void check(unsigned group,const char *tag,int p,int r,int i,ppf_t *g,mpfr_t ref,int pt,int mt,unsigned mf,ppf_context_t *c){
 mpfr_t out;mpfr_init2(out,p);export_exact(out,g);++cases[group];
 if(pt==PPF_TERNARY_ERROR||!ppf_validate(g)||!same(out,ref)||signum(pt)!=signum(mt)||((c->flags&63)!=mf)){
  if(failures<20){fprintf(stderr,"FAIL %s p=%d r=%d i=%d pt=%d mt=%d pf=%u mf=%u\n",tag,p,r,i,pt,mt,c->flags,mf);mpfr_fprintf(stderr,"got=%Ra ref=%Ra\n",out,ref);}++failures; ++group_failures[group];
 }
 mpfr_clear(out);
}
static void wide(ppf_context_t *c){ppf_context_set_range(c,PPF_EMIN_MIN,PPF_EMAX_MAX);mpfr_set_emin(PPF_EMIN_MIN);mpfr_set_emax(PPF_EMAX_MAX);}
static void setz(ppf_t *p,mpfr_ptr m,mpz_srcptr z,long e,ppf_context_t *c){
 int pt=ppf_set_z_2exp(p,z,e,PPF_RNDN,c),mt=mpfr_set_z_2exp(m,z,e,MPFR_RNDN);
 if(pt==PPF_TERNARY_ERROR||signum(pt)!=signum(mt))die("input assignment");
}
static void arithmetic(ppf_context_t *c){
 const int precs[]={2,3,7,24,53,63,64,65,127,128,129,257};
 gmp_randstate_t rs;gmp_randinit_mt(rs);gmp_randseed_ui(rs,0x20261022);
 mpz_t za,zb;mpz_inits(za,zb,NULL);
 for(unsigned pi=0;pi<sizeof(precs)/sizeof(*precs);pi++)for(int alias=0;alias<3;alias++){
  int p=precs[pi],ap=alias==1?p:p+11,bp=alias==2?p:p+17;
  ppf_t a,b,g;ppf_init2_ctx(&a,ap,c);ppf_init2_ctx(&b,bp,c);ppf_init2_ctx(&g,p,c);
  mpfr_t ma,mb,mr;mpfr_init2(ma,ap);mpfr_init2(mb,bp);mpfr_init2(mr,p);
  for(int i=0;i<120;i++){
   mpz_urandomb(za,rs,ap);mpz_setbit(za,ap-1);mpz_urandomb(zb,rs,bp);mpz_setbit(zb,bp-1);
   if(i&1)mpz_neg(za,za);
   if(i&2)mpz_neg(zb,zb);
   long ea=(i%17)-8-ap,eb=((i*7)%17)-8-bp;
   if(i%10==0){mpz_set(zb,za);eb=ea;}
   for(int r=0;r<5;r++)for(int op=0;op<4;op++){
    wide(c);setz(&a,ma,za,ea,c);setz(&b,mb,zb,eb,c);
    if(i&4){ppf_context_set_range(c,-9,9);mpfr_set_emin(-9);mpfr_set_emax(9);}
    mpfr_clear_flags();c->flags=0;int pt,mt;ppf_t *dst=alias==1?&a:alias==2?&b:&g;
    if(op==0){mt=mpfr_add(mr,ma,mb,(mpfr_rnd_t)r);pt=ppf_add(dst,&a,&b,(ppf_rnd_t)r,c);}
    else if(op==1){mt=mpfr_sub(mr,ma,mb,(mpfr_rnd_t)r);pt=ppf_sub(dst,&a,&b,(ppf_rnd_t)r,c);}
    else if(op==2){mt=mpfr_mul(mr,ma,mb,(mpfr_rnd_t)r);pt=ppf_mul(dst,&a,&b,(ppf_rnd_t)r,c);}
    else{mt=mpfr_div(mr,ma,mb,(mpfr_rnd_t)r);pt=ppf_div(dst,&a,&b,(ppf_rnd_t)r,c);}
    unsigned mf=mflags();wide(c);char tag[80];snprintf(tag,sizeof(tag),"arith op=%d alias=%d",op,alias);unsigned long previous=failures;check(0,tag,p,r,i,dst,mr,pt,mt,mf,c);if(failures>previous&&group_failures[0]<10){mpfr_fprintf(stderr,"a=%Ra b=%Ra\n",ma,mb);}
   }
  }
  ppf_clear(&a);ppf_clear(&b);ppf_clear(&g);mpfr_clears(ma,mb,mr,(mpfr_ptr)0);
 }
 mpz_clears(za,zb,NULL);gmp_randclear(rs);
}
static void conversion(ppf_context_t *c){
 wide(c);ppf_t x;ppf_init2_ctx(&x,1200,c);mpfr_t m;mpfr_init2(m,1200);mpz_t z;mpz_init(z);
 const long exps[]={-1077,-1076,-1075,-1074,-1073,-1023,-1022,-151,-150,-149,-148,-127,-126,-54,-53,-25,-24,0,126,127,128,1022,1023,1024};
 for(unsigned ei=0;ei<sizeof(exps)/sizeof(*exps);ei++)for(int bit=0;bit<3;bit++)for(int k=-3;k<=3;k++)for(int neg=0;neg<2;neg++){
  mpz_set_ui(z,1);mpz_mul_2exp(z,z,bit==0?0:bit==1?24:53);mpz_add_ui(z,z,4+k);if(neg)mpz_neg(z,z);
  setz(&x,m,z,exps[ei]-(bit==0?0:bit==1?24:53),c);
  for(int r=0;r<5;r++){
   double pd=ppf_get_d(&x,(ppf_rnd_t)r,c),md=mpfr_get_d(m,(mpfr_rnd_t)r);
   float pf=ppf_get_flt(&x,(ppf_rnd_t)r,c),mf=mpfr_get_flt(m,(mpfr_rnd_t)r);cases[1]+=2;
   if(memcmp(&pd,&md,sizeof pd)||memcmp(&pf,&mf,sizeof pf)){if(failures<20)fprintf(stderr,"FAIL conversion e=%ld bit=%d k=%d neg=%d r=%d d=%a/%a f=%a/%a\n",exps[ei],bit,k,neg,r,pd,md,(double)pf,(double)mf);++failures;++group_failures[1];}
  }
 }
 mpz_clear(z);mpfr_clear(m);ppf_clear(&x);
}
static void subnormal(ppf_context_t *c){
 mpz_t z;mpz_init(z);
 for(int p=2;p<=20;p++){
  ppf_t x;ppf_init2_ctx(&x,p,c);mpfr_t m;mpfr_init2(m,p);
  for(int n=1;n<=127;n++)for(int neg=0;neg<2;neg++)for(int r=0;r<5;r++){
   wide(c);mpz_set_si(z,neg?-n:n);int mt=mpfr_set_z_2exp(m,z,-32,(mpfr_rnd_t)r);int pt=ppf_set_z_2exp(&x,z,-32,(ppf_rnd_t)r,c);
   if(signum(pt)!=signum(mt))die("subnormal incoming");
   /* mpfr_subnormalize requires its input already inside the active exponent range. */
   if(!mpfr_zero_p(m)&&mpfr_get_exp(m)<-30)continue;
   ppf_context_set_range(c,-30,100);mpfr_set_emin(-30);mpfr_set_emax(100);mpfr_clear_flags();c->flags=0;
   mt=mpfr_subnormalize(m,mt,(mpfr_rnd_t)r);pt=ppf_subnormalize(&x,pt,(ppf_rnd_t)r,c);unsigned mf=mflags();wide(c);check(2,"subnormalize",p,r,n,&x,m,pt,mt,mf,c);
  }
  mpfr_clear(m);ppf_clear(&x);
 }
 mpz_clear(z);
}
static void limits(ppf_context_t *c){
 const ppf_exp_t centers[]={PPF_EMIN_MIN,PPF_EMAX_MAX,-1073741823,1073741823};
 const int ps[]={2,53,64,65,257};mpz_t z;mpz_init(z);
 for(unsigned pi=0;pi<5;pi++){
  int p=ps[pi];ppf_t x;ppf_init2_ctx(&x,p,c);mpfr_t m;mpfr_init2(m,p);
  for(unsigned ci=0;ci<4;ci++)for(int delta=-3;delta<=3;delta++)for(int n=-7;n<=7;n++)for(int r=0;r<5;r++){
   wide(c);if(ci>=2){ppf_context_set_range(c,PPF_EMIN_DEFAULT,PPF_EMAX_DEFAULT);mpfr_set_emin(PPF_EMIN_DEFAULT);mpfr_set_emax(PPF_EMAX_DEFAULT);}
   mpz_set_si(z,n);ppf_exp_t e=centers[ci]+delta;mpfr_clear_flags();c->flags=0;
   int mt=mpfr_set_z_2exp(m,z,e,(mpfr_rnd_t)r),pt=ppf_set_z_2exp(&x,z,e,(ppf_rnd_t)r,c);unsigned mf=mflags();wide(c);check(3,"exp_limit",p,r,ci*100+delta*10+n,&x,m,pt,mt,mf,c);
  }
  mpfr_clear(m);ppf_clear(&x);
 }
 mpz_clear(z);
}
static void interval(ppf_context_t *c){
 mpz_t lo,hi,mid;mpz_inits(lo,hi,mid,NULL);
 for(int p=2;p<=8;p++){
  ppf_t x;ppf_init2_ctx(&x,p,c);mpfr_t ref,got;mpfr_init2(ref,p);mpfr_init2(got,p);
  for(int range=0;range<2;range++)for(int e=-8;e<=4;e+=2)for(int a=-32;a<=32;a++)for(int w=0;w<=4;w++)for(int r=0;r<6;r++){
   wide(c);if(range){ppf_context_set_range(c,-3,3);mpfr_set_emin(-3);mpfr_set_emax(3);}
   mpz_set_si(lo,a);mpz_set_si(hi,a+w);ppf_set_si(&x,1,PPF_RNDN,c);c->flags=0;int t=777;
   int s=ppf_set_dyadic_interval(&x,lo,hi,e,(ppf_rnd_t)r,&t,c);cases[4]++;
   if(s==PPF_INTERVAL_DECIDED){decided++;for(int j=0;j<=4;j++){
    mpz_set_si(mid,4*a+j*w);int mt=mpfr_set_z_2exp(ref,mid,e-2,(mpfr_rnd_t)(r==5?MPFR_RNDZ:r));
    mpfr_exp_t emin=mpfr_get_emin(),emax=mpfr_get_emax();mpfr_set_emin(PPF_EMIN_MIN);mpfr_set_emax(PPF_EMAX_MAX);export_exact(got,&x);mpfr_set_emin(emin);mpfr_set_emax(emax);
    if(!same(ref,got)||signum(mt)!=signum(t)){if(failures<20)fprintf(stderr,"FAIL interval p=%d range=%d e=%d a=%d w=%d r=%d j=%d t=%d mt=%d\n",p,range,e,a,w,r,j,t,mt);failures++;group_failures[4]++;}
   }}else if(s==PPF_INTERVAL_UNDECIDED){undecided++;if(t!=777||ppf_cmp_ui(&x,1,c)!=0||c->flags)die("undecided mutated result");}else die("interval unexpected error");
  }
  /* Explicit reversed endpoint negative control. */
  wide(c);mpz_set_ui(lo,2);mpz_set_ui(hi,1);int t=777;ppf_set_si(&x,1,PPF_RNDN,c);c->flags=0;
  if(ppf_set_dyadic_interval(&x,lo,hi,0,PPF_RNDN,&t,c)!=PPF_INTERVAL_ERROR||t!=777||ppf_cmp_ui(&x,1,c)!=0||!(c->flags&PPF_FLAG_ERANGE))die("reversed interval negative control");
  cases[5]++;
  mpfr_clears(ref,got,(mpfr_ptr)0);ppf_clear(&x);
 }
 mpz_clears(lo,hi,mid,NULL);
}
int main(void){ppf_context_t c;if(ppf_context_init(&c))die("context");printf("MPFR=%s GMP=%s\n",mpfr_get_version(),gmp_version);arithmetic(&c);conversion(&c);subnormal(&c);limits(&c);interval(&c);for(int i=0;i<6;i++)printf("%s=%lu failures=%lu\n",names[i],cases[i],group_failures[i]);printf("interval_decided=%lu interval_undecided=%lu failures=%lu\n",decided,undecided,failures);ppf_context_clear(&c);return failures?1:0;}
