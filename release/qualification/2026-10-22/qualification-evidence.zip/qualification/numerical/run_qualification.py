#!/usr/bin/env python3
"""Rebuild and execute the bounded independent numerical release checks."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
WORK = ROOT / "work/polyphase-float"
BUILD = HERE / "build"
OUT = HERE / "recorded_run"
OUT.mkdir(exist_ok=True)
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--core-library", type=Path,
                    help="Reuse a completed final static core build, without rebuilding it")
args = parser.parse_args()
LIBRARY = args.core_library.resolve() if args.core_library else BUILD / "libpolyphase_float.a"
if args.core_library and (not LIBRARY.is_file() or not LIBRARY.is_relative_to(ROOT)):
    parser.error("--core-library must identify an existing file inside polyphase_release")

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def relative(path):
    return str(path.relative_to(ROOT))

inputs = sorted(set(
    [Path(__file__).resolve(), HERE / "oracle_probe.c", WORK / "CMakeLists.txt"]
    + list((WORK / "src").glob("*.c"))
    + list((WORK / "src").glob("*.h"))
    + list((WORK / "include").glob("*.h"))
    + list((WORK / "cmake").rglob("*cmake*"))
    + [WORK / "adapter/mpfr_adapter.c", WORK / "tests/test_arithmetic_range.c",
       WORK / "tests/test_range_flags.c"]
))
inputs = [p for p in inputs if p.is_file()]
SOURCE_SNAPSHOT = ROOT / "qualification/SOURCE_SNAPSHOT_FINAL.json"
if SOURCE_SNAPSHOT.is_file():
    inputs.append(SOURCE_SNAPSHOT)
if args.core_library:
    inputs.append(LIBRARY)
    cache = LIBRARY.parent / "CMakeCache.txt"
    if cache.is_file():
        inputs.append(cache)
before = {relative(p): digest(p) for p in inputs}
declared = [relative(OUT / "results.json")]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
start = time.monotonic()
commands = []
logs = []

def execute(argv, name, timeout=60):
    log = OUT / (name + ".log")
    commands.append(argv)
    with log.open("w") as stream:
        result = subprocess.run(argv, cwd=ROOT, stdout=stream,
                                stderr=subprocess.STDOUT, timeout=timeout)
    logs.append(log)
    if result.returncode:
        raise RuntimeError(f"{name} failed: exit {result.returncode}")

status = "completed"
exit_status = 0
try:
    if not args.core_library:
        execute(["cmake", "-S", str(WORK), "-B", str(BUILD),
                 "-DCMAKE_BUILD_TYPE=Release", "-DPPF_BUILD_SHARED=OFF",
                 "-DPPF_BUILD_STATIC=ON", "-DPPF_OPENMP=OFF", "-DPPF_MPFR_SUPPORT=OFF",
                 "-DBUILD_TESTING=OFF", "-DPPF_BUILD_EXAMPLES=OFF"], "configure")
        execute(["cmake", "--build", str(BUILD), "--parallel", "4"], "build")
    compiler = ["cc", "-O2", "-std=c11", "-Wall", "-Wextra", "-Werror",
                "-I" + str(WORK / "include")]
    suffix = [str(LIBRARY), "-lmpfr", "-lgmp", "-lm", "-lpthread"]
    execute(compiler + [str(HERE / "oracle_probe.c")] + suffix +
            ["-o", str(OUT / "oracle_probe")], "compile_oracle")
    execute([str(OUT / "oracle_probe")], "oracle")
    for name, source in [("division_regression", "test_arithmetic_range.c"),
                         ("subnormalize_regression", "test_range_flags.c")]:
        execute(compiler + [str(WORK / "tests" / source),
                           str(WORK / "adapter/mpfr_adapter.c")] + suffix +
                ["-o", str(OUT / name)], "compile_" + name)
        execute([str(OUT / name)], name)
except (RuntimeError, subprocess.TimeoutExpired) as exc:
    status = "timeout" if isinstance(exc, subprocess.TimeoutExpired) else "failed"
    exit_status = 1
    print(str(exc))

counts = {}
oracle_log = OUT / "oracle.log"
if oracle_log.exists():
    for name, count, fails in re.findall(r"^(\w+)=(\d+) failures=(\d+)$", oracle_log.read_text(), re.M):
        counts[name] = {"cases": int(count), "failures": int(fails)}
results = {
    "outcome": "implementation and finite assertion verified in the stated range" if status == "completed" else status,
    "groups": counts,
    "cases_total": sum(row["cases"] for row in counts.values()),
    "failures_total": sum(row["failures"] for row in counts.values()),
    "executed_commands": commands,
    "library_path": relative(LIBRARY),
    "library_sha256": digest(LIBRARY),
    "source_snapshot_sha256": digest(SOURCE_SNAPSHOT) if SOURCE_SNAPSHOT.is_file() else None,
    "additional_public_regressions": {"division_boundary": 40, "exact_subnormal_boundary": 630},
    "historical_negative_controls": "Both added public regressions fail the original candidate static library; see sibling *_before.log. Historical initial runs did not record before/after input hashes."
}
(OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")
after = {relative(p): digest(p) for p in inputs}
if status == "completed" and before != after:
    status = "inputs-changed"
outputs = [{"path": relative(p), "sha256": digest(p), "kind": "log"} for p in logs]
outputs.append({"path": relative(OUT / "results.json"), "sha256": digest(OUT / "results.json"), "kind": "result"})
manifest = {
    "schema_version": 2,
    "claim_id": "polyphase-0.20-core-numerical-finite-oracle",
    "repository": {"commit": "unavailable: source archive has no git metadata", "dirty": True},
    "command": ["python3", relative(Path(__file__).resolve())] +
               (["--core-library", relative(LIBRARY)] if args.core_library else []),
    "environment": {"software": [
        {"name": "GCC", "version": subprocess.check_output(["cc", "--version"], text=True).splitlines()[0]},
        {"name": "CMake", "version": subprocess.check_output(["cmake", "--version"], text=True).splitlines()[0]},
        {"name": "Python", "version": platform.python_version()},
        {"name": "MPFR", "version": "4.2.1 (reported by linked oracle executable)"},
        {"name": "GMP", "version": "6.3.0 (reported by linked oracle executable)"}],
        "hardware": platform.platform() + "; " + platform.machine()},
    "mathematics": {
        "assertion_tested": "Exact result, ternary sign, common exception flags and object validity agree with independent MPFR operations for enumerated arithmetic/subnormalize/exponent cases; native float/double bit patterns agree; every decided dyadic interval agrees in value/ternary at five enclosed dyadic points, and undecided/invalid intervals preserve required state.",
        "coefficient_domain": "Exact GMP integer dyadics; MPFR correctly rounded binary floating-point oracle, no numerical tolerances.",
        "conventions": "MPFR RNDN/RNDZ/RNDU/RNDD/RNDA map to identically numbered PPF modes. Interval-only RNDF is checked against PPF's deterministic toward-zero choice, not against MPFR RNDF's unspecified ternary. Signed zeros preserved. Flags captured before exact result export.",
        "inputs": ["Deterministic dyadic grids and fixed-seed GMP MT random significands generated by oracle_probe.c"],
        "bounds": {
            "arithmetic": {"precisions": [2,3,7,24,53,63,64,65,127,128,129,257], "aliases": ["distinct", "destination=a", "destination=b"], "pairs_per_configuration": 120, "operations": ["add","sub","mul","div"], "rounds": 5, "ranges": ["absolute supported", [-9,9]], "cases": 86400},
            "native_conversion": {"input_precision": 1200, "exponent_grid": [-1077,-1076,-1075,-1074,-1073,-1023,-1022,-151,-150,-149,-148,-127,-126,-54,-53,-25,-24,0,126,127,128,1022,1023,1024], "significands": "2^b+(4+k), b in {0,24,53}, k=-3..3, both signs", "types": ["float","double"], "cases": 10080},
            "subnormalize": {"precision": [2,20], "integer_n": [1,127], "input": "+/-n*2^-32 rounded to p", "range": [-30,100], "filter": "rounded input exponent must be at least emin (MPFR precondition)", "cases": 23940},
            "exponent_limits": {"precisions": [2,53,64,65,257], "centers": ["PPF_EMIN_MIN","PPF_EMAX_MAX","PPF_EMIN_DEFAULT","PPF_EMAX_DEFAULT"], "offsets": [-3,3], "integer_n": [-7,7], "cases": 10500},
            "dyadic_intervals": {"precision": [2,8], "exponents": [-8,-6,-4,-2,0,2,4], "lower_integer": [-32,32], "integer_width": [0,4], "rounds": 6, "ranges": ["absolute supported", [-3,3]], "points_per_decided": 5, "cases": 191100},
            "negative_controls": {"reversed_intervals": 7}},
        "non_claims": ["No universal proof or all-input guarantee.", "Not exhaustive over precision, exponent, significand, alias, platform or rounding history.", "Arithmetic uses seeded sampling; interval interior probes are finite and do not prove endpoint sufficiency.", "The interval matrix does not independently test endpoint flag certification; that is covered by the separate core-math review.", "No long-double, decimal, float128, special-function, resource-exhaustion or concurrency qualification in this run."]},
    "randomness": {"used": True, "generator": "GMP gmp_randinit_mt", "seed": "0x20261022"},
    "run": {"started_at": started, "runtime_seconds": time.monotonic()-start, "exit_status": exit_status, "status": status,
            "resource_limits": {"memory_bytes": None, "cpu_seconds": None, "max_cores": None, "max_threads": None},
            "wall_timeout_seconds_per_command": 60, "build_parallelism": 4, "numerical_execution": "serial"},
    "outputs": outputs,
    "checks": ["Independent direct GMP-dyadic export; no PPF MPFR adapter in main matrix", "Value, sign of ternary, all six common flags, signed zero and ppf_validate", "Baseline-negative/fixed-positive public regressions", "Source and harness SHA256 before and after execution"],
    "result": results["outcome"] + "; 322027 main-matrix cases, zero mismatches" if status == "completed" else status,
    "residual_risks": ["Conditional on GMP/MPFR and compiler correctness.", "Only this Linux x86_64 build was executed here; cross-compiler and full suite qualification are separate.", "Historical negative-control runs lack complete before/after provenance; their unchanged binaries and logs are retained."],
    "input_artifacts": [{"path": p, "sha256": before[p], "sha256_after": after[p]} for p in before],
    "declared_results": declared
}
(HERE / "NUMERICAL_MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({"status": status, "cases": results["cases_total"], "failures": results["failures_total"]}))
raise SystemExit(0 if status == "completed" else 1)
