# Core numerical release qualification

The repaired source passes the bounded independent oracle matrix: **322,027 cases, zero mismatches**. The recorded run completed successfully and its v2 manifest validates against the current inputs. This is finite numerical evidence, not an all-input correctness proof.

## Reproduce

From the `polyphase_release` directory:

```sh
python3 qualification/numerical/run_qualification.py
python3 qualification/numerical/validate_manifest.py qualification/numerical/NUMERICAL_MANIFEST.json --root .
```

The wrapper records source and harness SHA-256 hashes before and after execution, compiles the independent probe and two public regression tests, and records commands, results and output hashes. By default it rebuilds a serial Release static core. To reuse the completed release build without concurrent compilation, pass `--core-library PATH_TO_FINAL_STATIC_LIBRARY`; the supplied library and its CMake cache are then pinned as inputs. The exact final command is recorded in `NUMERICAL_MANIFEST.json`; `recorded_run/results.json` contains the executed commands and tested-library path/hash. The main matrix links GMP and MPFR directly, without using the PPF MPFR adapter for its oracle or exact result export. The two repository tests use the existing adapter, compiled from the pinned source.

Environment: Linux x86_64, GCC 13.3.0, CMake 3.28.3, GMP 6.3.0 and MPFR 4.2.1. Each subprocess has a 60-second wall timeout; numerical execution is serial. The recorded run completed without truncation or timeout. There is no git metadata in the working source archive; the manifest identifies inputs individually instead of inventing a commit.

## Finite coverage

| Group | Cases | Scope |
|---|---:|---|
| Arithmetic and aliasing | 86,400 | Add/subtract/multiply/divide; destination precisions 2, 3, 7, 24, 53, 63, 64, 65, 127, 128, 129, 257; distinct output and either input alias; 120 seeded pairs per configuration; five deterministic rounding modes; full supported range or [-9,9] |
| Native conversion | 10,080 | Float and double; both signs; exact 1,200-bit dyadics across explicit subnormal, normal and overflow boundaries; five modes; bitwise comparison |
| Subnormal emulation | 23,940 | Precisions 2–20; signed n·2^-32 for n=1…127, first rounded at destination precision; [-30,100] range; five modes; input-range precondition enforced |
| Exponent limits | 10,500 | Precisions 2, 53, 64, 65, 257; integer multipliers -7…7; ±3 around each public absolute/default exponent endpoint; five modes |
| Dyadic interval assignment | 191,100 | Precisions 2–8; exponent -8…4 in steps of two; lower integer -32…32; integer width 0…4; two ranges; all six modes |
| Negative controls | 7 | Reversed interval endpoints rejected; destination and ternary preserved; ERANGE raised |

The arithmetic generator is GMP MT seeded with `0x20261022`; this is reproducible sampling, not exhaustive enumeration of significands. The native-conversion exponent grid and every other bound are recorded in the manifest and source. Input significands in that grid are signed `2^b+(4+k)`, with b∈{0,24,53}, k=-3…3 and exponent adjusted by b. Exponent-limit cases use `ppf_set_z_2exp`, not every arithmetic API.

Value, signed zero, ternary sign, the six shared exception flags and object validity are checked for arithmetic, subnormalize and exponent-limit cases. Conversion checks compare float/double bit patterns. Interval assignment produced 77,424 DECIDED and 113,676 UNDECIDED results. Each decided result is checked at both endpoints and three interior dyadic points; undecided results must preserve destination, ternary and flags. The interval matrix does not independently certify flags on decided intervals. That issue is covered by the separate core-math review. Interval-only faithful mode is compared with the implementation's deterministic toward-zero choice; no comparison is made with MPFR faithful ternary, which is unspecified.

## Confirmed defects repaired

**Division carry at the exponent ceiling.** At destination precision two and range [-9,9], examples such as 7/(15·2^-10) should overflow in nearest rounding. Before repair, the limb rounder staged a NaN with nonzero `used_limbs`; when rounding carried across `emax`, the interval fallback rejected that invalid object and returned ERANGE. `src/limb_round.c` now keeps the canonical NaN staging invariant and sets the used-limb count immediately before the successful final mask/commit. This preserves the existing arithmetic decisions and makes the fallback admissible.

`tests/test_arithmetic_range.c` adds 40 signed, directed-rounding, alias and exact-tie cases. The added regression fails against the original candidate library at `pt != PPF_TERNARY_ERROR`, and passes after repair. The independent arithmetic matrix's five original mismatches are gone.

**Exact subnormal emulation flags.** At precision two, `emin=-30`, x=2^-31 and incoming ternary zero, subnormal emulation leaves x exact but must raise UNDERFLOW under the MPFR API contract. Previously `src/range_flags.c` raised that flag only for nonzero returned ternary. It now raises UNDERFLOW after every successful reduced-precision rounding stage, while raising INEXACT only for nonzero returned ternary. Full-precision early returns are unchanged. This rule is specific to subnormal emulation and does not alter ordinary arithmetic's underflow model.

`tests/test_range_flags.c` adds 630 exact signed powers of two at subnormal and full-precision boundaries, with five rounding modes. The added regression fails against the original candidate library on underflow-flag comparison and passes after repair. The independent subnormalize matrix's 9,390 original mismatches are gone. The behavior is documented in `docs/RANGE_FLAGS_ROOTS_DIVISION.md` and matches the [MPFR 4.2.1 description of mpfr_subnormalize](https://www.mpfr.org/mpfr-4.2.1/mpfr.html#Exception-Related-Functions).

The independent core-math reviewer reviewed both repairs and confirmed their source logic. I also independently reviewed that agent's widened integer-rounding bit-count comparison and the allocation-audit agent's native-conversion half/sticky-bit replacement. Those repairs have their own regression evidence.

## Supported limits and exclusions

The public exponent defaults are [-1073741823,1073741823]. Absolute context limits are `INT64_MIN/4` and `INT64_MAX/4`. `ppf_prec_t` is uint64_t, but precision validation additionally requires precision at least two, no more than `SIZE_MAX/2`, and a representable limb allocation. These are representational bounds; they are not promises that physical memory can accommodate every accepted precision. GMP shift interfaces and operation-specific checked arithmetic impose further practical constraints.

This run exercises precision only up to 1,200 bits for conversion and 257 bits for arithmetic/exponent limits. It does not allocate near the formal precision ceiling, evaluate all precisions, or certify every rounding path at every exponent. Long double, decimal, float128, special functions, thread behavior and allocation exhaustion are outside this probe. Cross-compiler, sanitizer and full CTest qualification are separate workstreams. The result remains conditional on GMP, MPFR and compiler correctness.

Historical exploratory and negative-control logs are retained as `oracle_before_fixes_*` and `*_regression_before.log`, alongside the corresponding linked test binaries. Those exploratory runs did not record complete before/after input hashes and are not represented as v2 provenance. The recorded final run does.
