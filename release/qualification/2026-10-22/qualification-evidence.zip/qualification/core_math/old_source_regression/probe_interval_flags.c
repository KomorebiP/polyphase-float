#include "src/round.c"
#include "polyphase_float.h"
#include <stdio.h>
int main(void){ppf_context_t c;ppf_t x;mpz_t l,u;int t=0;ppf_context_init(&c);ppf_context_set_range(&c,0,10);ppf_init2_ctx(&x,2,&c);mpz_inits(l,u,NULL);mpz_set_ui(l,19);mpz_set_ui(u,31);ppf_context_flags_clear(&c,PPF_FLAGS_ALL);int s=ppf_set_dyadic_interval(&x,l,u,-6,PPF_RNDN,&t,&c);printf("interval status=%d ternary=%d flags=%u\n",s,t,c.flags);ppf_context_flags_clear(&c,PPF_FLAGS_ALL);t=ppf_set_z_2exp(&x,u,-6,PPF_RNDN,&c);printf("exact upper ternary=%d flags=%u\n",t,c.flags);ppf_context_flags_clear(&c,PPF_FLAGS_ALL);t=ppf_set_z_2exp(&x,l,-6,PPF_RNDN,&c);printf("exact lower ternary=%d flags=%u\n",t,c.flags);mpz_clears(l,u,NULL);ppf_clear(&x);ppf_context_clear(&c);return 0;}
