# Core rounding and certified-constant review

The reviewed claim is that exact dyadic rounding and accepted constant enclosures produce the requested binary value, ternary direction, and numerical range flags. The original candidate, commit `70ce732e2244effcd7bd0d450618e5734546a2b8`, is **refuted** for two concrete rounding cases below. Both defects have been corrected in the working candidate. The overall post-correction verdict is **conditional on named inputs**: the local decision rules and constant-tail arguments were checked, but this review is not a formal proof of every arithmetic primitive, optimized packet operation, machine-size control path, or supported input. The finite implementation assertions passed in the stated range.

This is a fresh AI subagent review within the same task and execution environment. It does not satisfy the project's requirement for outside correctness reproductions or an outside mathematical reviewer. No version 1.0 promotion follows from it.

## Claim cards and dependency graph

1. **Dyadic rounding.** For a valid initialized precision-p destination, p≥2, a valid context/range and rounding mode, round the exact signed integer times a power of two. The sign of the ternary return must equal the sign of stored value minus exact value. Faithful mode may select either neighboring representable value. Dependencies: GMP exact integers; normalized object storage; checked exponent addition; quotient/remainder decomposition; carry and range handling.
2. **Interval finalization.** Given finite ordered integer endpoints L≤U at common scale 2^e, accept only if every enclosed real value has the same rounded result and ternary direction, and the interval certifies the same underflow/overflow state. Dependencies: claim 1, monotonic rounding, exact comparison. A nondegenerate interval containing the proposed output cannot establish a nonzero ternary direction and must remain undecided.
3. **Constants.** Each successful builder supplies L·2^e≤c≤U·2^e for pi, log(2), Euler's constant or Catalan's constant. Dependencies: exact packet identities or directed elementary arithmetic; a proved omitted-tail bound; claim 2; cache validity. Builder/precision-attempt exhaustion is an error, not evidence of an enclosure or of convergence at every requested precision.

The dependency chain is `integer/primitive arithmetic → builder enclosure → endpoint rounding → interval decision → destination/cache commit`. External leaves are the Chudnovsky identity, positive-real digamma remainder theorem, and Catalan identity. Mathematical identities do not establish the correctness of their C implementations by themselves.

## Confirmed defects and corrections

### Full-width discarded-bit counts

In the baseline `src/round.c`, `ppf_set_z_2exp` stores a discarded-bit count in `unsigned long` but passes it to `rounded_increment(..., unsigned shift)`. Supported LP64 builds therefore narrow the count from 64 to 32 bits.

Take D=4,294,967,298, positive quotient 3 and remainder 3. The nearest-rounding comparison is 3 versus 2^(D−1), so the increment must be zero. The unchanged production helper receives D modulo 2^32=2 and increments instead. `SHIFT_NARROWING_WITNESS.json` records the direct source-helper observation.

A corresponding public input is precision 2, emin=0, emax=2, integer z=3·2^D+3, exponent −D. Its exact value is 3+3·2^(−D) and should round to 3. Because its normalized exponent is emax, the fast limb path is bypassed. The narrowed helper rounds the significand up to 4 and triggers overflow. This complete public call was not executed: constructing z would require more than 512 MiB. The helper witness uses only small integers and its exact implication is stated separately.

The correction uses `mp_bitcnt_t`. For nonzero nonnegative remainder r, its binary length b decides comparison with 2^(D−1): b<D means below; b>D means above; b=D is equal exactly when r is a power of two. Popcount distinguishes equality from above-half without allocating the huge half-power. The tie then uses quotient parity. The zero-remainder fast return still prevents any half/tie operation on exact inputs. Support reviewer independently checked this reasoning.

### Range flags must also be certified

At p=2, emin=0, emax=10, use the interval [19,31]·2^(−6) and nearest rounding. Both endpoints round to 1/2 with positive ternary. The lower endpoint sets UNDERFLOW|INEXACT (17); the upper sets INEXACT only (16). The baseline accepted the interval and ORed the flags, although an exact value at the upper endpoint does not underflow.

The correction returns UNDECIDED when endpoint underflow/overflow flags differ. No destination, ternary-output or context-flag commit occurs on that path. Singleton intervals and intervals whose range flags agree retain their existing behavior. INEXACT remains consistent: a strict common ternary proves inexactness; an exact singleton is exact. Existing caller flags remain sticky. This is a refinement of the existing certificate requirement, not a new numerical formula.

The public header comment and `docs/CERTIFIED_CONSTANTS.md` state the range-flag condition. `tests/test_rounding_width.c` contains the actual-production-helper width regression and the public interval non-commit/flags regression. It is registered with both CMake/CTest and Make, including the hardening/sanitize paths, without adding an exported API.

## Obligation matrix

| Obligation | Status | Evidence and limits |
|---|---|---|
| Quotient/remainder nearest-even and directed increments | Passed after correction | Binary-length argument above; 98,210 finite helper checks, including large shifts; baseline fails the same test. |
| Limb guard/sticky/parity selection | Passed in reviewed branches | Guard is the highest discarded bit; remaining discarded bits and external sticky distinguish above-half; parity resolves exact halves. Inputs must obey the internal nonnegative magnitude/sticky contract. |
| Sign of ternary and directed sign reversal | Passed in reviewed branches | Increment versus truncation reverses ternary sign for negative operands; negation exchanges RNDU/RNDD. |
| Interval value and ternary | Passed conditionally on endpoint rounding | Monotonicity plus equal endpoint outputs proves value; output strictly above U or below L proves direction; exact singleton proves zero. |
| Interval numerical range flags | Failed in baseline; corrected | Explicit [19,31]·2^(−6) counterexample; disagreement now forces refinement. |
| Log(2) packet and tail | Passed at mathematical level | Transfer-law induction, ratio bound, outward floor/ceiling conversion; finite separate rational implementation checks. |
| Pi radius certificate | Passed at mathematical level for the default exact path | Bound decomposition below; external identity authenticated; optimized packet arithmetic remains dependent on its correctness. |
| Euler omitted correction | Passed conditionally on directed arithmetic/logarithm | Positive-real digamma theorem supplies signed first-omitted-term remainder for each finite truncation. |
| Catalan recurrence and tail | Passed conditionally on directed pi/sqrt/log and external identity | Exact ratio is below 1/4 for every n≥0, not merely eventually. |
| Cache decisions | Reviewed, no counterexample found | Cache stores an enclosure; rounded-result cache is rounding-mode/precision-specific and used only in the recorded normal range. Concurrency and allocation failure have separate qualification. |
| Universal termination/correctness of every precision and primitive | Not addressed | Finite retries and work caps remain; no whole-library formal proof or outside reproduction. |

## Constant arguments checked against source

**Log(2).** In `src/constant_log2.c`, a leaf has P=2k+1, Q=9(2k+3), T=Q. The transfer law preserves T/Q as the finite product-sum and P/Q as the first omitted product. Its consecutive ratio is strictly below 1/9 for k≥0. Multiplying the geometric remainder by 2/3 gives an upper tail of 3P/(4Q); hence the source endpoints 8T/(12Q) and (8T+9P)/(12Q) enclose log(2). Floor on the lower scaled rational and ceiling on the upper preserve enclosure. A term-count estimate affects efficiency, not soundness of this bound.

**Pi.** Write A=13,591,409, B=545,140,134, C=640,320 and R=C^3/1728=151,931,373,056,000. The factorial coefficient's successive ratio is below 1/R. The full positive terms decrease because their ratio is bounded by (A+B)/(A·R)<1, as the initialization check establishes. For N≥1, the finite and infinite sums exceed A−1: the first correction is below 1 and the series alternates with decreasing terms. The omitted sum has magnitude less than (A+BN)/R^N.

The exact pi formula is 426880·sqrt(10005)/S. Replacing S by S_N gives scaled error less than `426880·101·2^s·(A+BN)/((A−1)^2·R^N)`. `tail_under_one_unit` checks a stricter integer inequality ensuring this is below one. Replacing the scaled square root with its floor contributes less than 426880/(A−1)<1 unit. The final nearest-integer quotient contributes at most 1/2 unit. Thus total error is below 5/2 units, inside the implemented radius four. The public builder forces the exact non-adic strict-final path and tests the tail before acceptance. The transfer law and common-factor cancellation preserve the ratios algebraically; this review does not exhaustively prove every optimized multiplication/scheduling implementation.

**Euler.** `src/special_common.c` constructs H_n−log(n)−1/(2n) and successive B_(2k)/(2k·n^(2k)) corrections. DLMF 5.11.2 and 5.11(ii), combined with psi(n)=H_(n−1)−gamma, put gamma between the partial expression and the expression including the next correction for positive n. Directed interval evaluation and `interval_minmax` retain those endpoints. The bound is valid for each finite truncation; it does not require the asymptotic series to converge. Limits n≤20,000 and k≤192 can prevent a requested precision from being certified, but do not invalidate a returned enclosure. Success still depends on the elementary log/interval primitives.

**Catalan.** The source recurrence corresponds to t_n=1/((2n+1)^2·binomial(2n,n)). Its ratio is (n+1)(2n+1)/(2(2n+3)^2), with

`1/4 − ratio = (6n+7)/(4(2n+3)^2) > 0`.

Therefore the remaining positive tail beginning at `next` is at most 4·next/3. The source adds this only to the upper endpoint and then applies the 3/8 multiplier. Its polynomial numerator/denominator fit LP64 throughout n<1,000,000. The base identity is recorded in the MPFR team's official Algorithms and Proofs, section 5.4, and matches the source normalization. MPFR uses the same identity, so differential agreement alone is not independent evidence for that identity.

## Computation and reproducibility

`run_audit.py` builds `probe_constants.c` with strict warnings and links the separately built core static archive. It records before/after hashes of source, public headers, harness, runner, static archive, MPFR header and runtime libraries. `COMPUTATION_MANIFEST.json` records a completed v2 run.

The precision list is 2, 3, 5, 24, 53, 63, 64, 65, 113, 127, 128, 129, 257, 512, 1024, 2048. For each of four constants, both higher-precision directed MPFR reference endpoints must lie inside the exported dyadic interval. All 64 passed. Across all six rounding modes, 384 value/ternary or faithful-neighbor checks passed; INEXACT was checked.

All 32 exported pi/log(2) intervals additionally contain exact Python Fraction reference enclosures: pi uses independent Machin arctangent alternating bounds, and log(2) uses direct rational summation with an exact geometric remainder. The reference tail target is 2^(−2600). These tests concern only the enumerated precisions, one worker and successful allocation; they do not prove universal correct rounding.

`ROUNDING_WIDTH_REGRESSION.json` records the baseline failure and fixed-source pass of the same bounded regression. CMake `rounding_width` and `object_model` tests passed; Make builds and runs the durable width regression. The release-wide local qualification was subsequently rerun on the frozen candidate; `../BUILD_QUALIFICATION_FINAL.json` records the passing aggregate scopes and preserves the initial execution-mode failures and recovery details.

Regeneration commands, from the repository root:

```sh
cmake -S . -B ../core-review-build -DPPF_BUILD_STATIC=ON -DPPF_MPFR_SUPPORT=OFF -DPPF_OPENMP=OFF -DBUILD_TESTING=ON
cmake --build ../core-review-build --target test_rounding_width test_object
ctest --test-dir ../core-review-build -R '^(rounding_width|object_model)$' --output-on-failure
make PPF_OPENMP=OFF bin/test_rounding_width
./bin/test_rounding_width
```

The standalone constants experiment has its exact local compile/run commands and input hashes in its manifest. Retained historical results are clearly separated under `baseline_constants/`; they are not current-source qualification.

## External source record and remaining gap

- Imin Chen and Gleb Glebov, *On Chudnovsky-Ramanujan Type Formulae*, arXiv:1609.05778v2, 30 June 2017, equation (1), Theorem 4.2 and its N=163 example: https://arxiv.org/pdf/1609.05778v2. The identity and normalization were authenticated and translated; the modular-function derivation was not reproved here.
- NIST DLMF, §5.11 equation 5.11.2 and §5.11(ii), positive-real remainder bound; checked 2026-10-22: https://dlmf.nist.gov/5.11. The exact positive-integer specialization and sign were checked.
- The MPFR Team, *The MPFR Library: Algorithms and Proofs*, official 69-page document, §5.4; checked 2026-10-22: https://www.mpfr.org/algorithms.pdf. Formula statement and recurrence normalization checked. The current PDF is unversioned; no claim is made that its historical bytes are permanently pinned.

Frozen-source local qualification and targeted downstream interval probes are complete in the separately recorded bounded scopes. The project still needs its documented outside reproductions and mathematical review for a 1.0 claim. Within this audit, the smallest unresolved proof implication is from all lower-level arithmetic/logarithm/square-root and optimized packet operations to universally correct enclosures at every admitted machine-sized input. This report neither fills that gap by counting tests nor changes the release's documented bounded contract.

## Frozen-candidate refresh

The constants experiment was rerun for source commit `ba82abe7cff3b77ba4d2b07833bcfda953e92a2c`, using the final GCC serial static library supplied by the clean qualification build. All 676 source-file hashes matched snapshot `6da1bcdac98a970b7cf8af5a54e379f191f7eab153b4e1d2fd30dcfeec9e37d2` before and after the experiment. All 64 directed interval enclosures, 384 rounding comparisons, and 32 independent exact-rational enclosure checks passed again. The refreshed computation manifest validates.

All production source files and the regression named in the original review retain their reviewed bytes. The public header changed only in three regenerated contract-digest string constants; `FINAL_HEADER_DIGEST_DELTA.patch` records the complete difference. The JSON preserves the earlier review hashes and adds this final binding explicitly. Earlier run files remain under `prefreeze_constants_20261022/`; they are historical evidence, not a second independent reproduction. Full qualification outcomes are recorded separately.
