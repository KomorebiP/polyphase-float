/* Diagnostic of the unchanged production helper; no large integer allocation. */
#include "/workspace/scratch/42e078a3c9ea/polyphase_release/work/polyphase-float/src/round.c"
#include <stdio.h>
int main(void) {
 mpz_t q,r;mpz_inits(q,r,NULL);mpz_set_ui(q,3);mpz_set_ui(r,3);
 volatile unsigned long large_shift=(unsigned long)UINT_MAX+3UL;
 int got=rounded_increment(PPF_RNDN,1,q,r,large_shift);
 printf("{\"shift\":%lu,\"helper_parameter_bits\":%zu,\"caller_parameter_bits\":%zu,\"quotient\":3,\"remainder\":3,\"got_increment\":%d,\"correct_increment\":0,\"source_helper_counterexample\":%s,\"full_size_public_call_executed\":false}\n",(unsigned long)large_shift,sizeof(unsigned)*CHAR_BIT,sizeof(unsigned long)*CHAR_BIT,got,got==1?"true":"false");
 mpz_clears(q,r,NULL);return got==1?0:1;
}
