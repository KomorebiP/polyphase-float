#include "polyphase_float.h"
#include <mpfr.h>
#include <stdio.h>
#include <stdlib.h>
static int refconstant(int id, mpfr_ptr x, mpfr_rnd_t r) {
 switch(id){case 1:return mpfr_const_pi(x,r);case 2:return mpfr_const_log2(x,r);case 3:return mpfr_const_euler(x,r);default:return mpfr_const_catalan(x,r);}
}
static int libconstant(int id, ppf_t*x, ppf_rnd_t r,ppf_context_t*c){
 switch(id){case 1:return ppf_const_pi(x,r,c);case 2:return ppf_const_log2(x,r,c);case 3:return ppf_const_euler(x,r,c);default:return ppf_const_catalan(x,r,c);}
}
static int signum(int x){return(x>0)-(x<0);}
int main(void){
 const unsigned precs[]={2,3,5,24,53,63,64,65,113,127,128,129,257,512,1024,2048};
 mpz_t l,u,z;mpz_inits(l,u,z,NULL);int count=0,rounds=0;
 printf("{\"gmp\":\"%s\",\"mpfr\":\"%s\",\"intervals\":[\n",gmp_version,mpfr_get_version());
 for(int id=1;id<=4;id++)for(size_t j=0;j<sizeof(precs)/sizeof(precs[0]);j++){
  unsigned p=precs[j]; ppf_exp_t e;ppf_context_t ctx;ppf_t x;
  ppf_free_constant_caches();
  if(ppf_get_constant_interval((ppf_constant_id_t)id,l,u,&e,p,1))return 10;
  mpfr_prec_t q=(mpfr_prec_t)mpz_sizeinbase(u,2)+128;
  if(q<(mpfr_prec_t)p+512)q=(mpfr_prec_t)p+512;
  mpfr_t lo,hi,rl,ru,got,rr,down,up;mpfr_inits2(q,lo,hi,rl,ru,(mpfr_ptr)0);
  if(mpfr_set_z_2exp(lo,l,(mpfr_exp_t)e,MPFR_RNDN)||mpfr_set_z_2exp(hi,u,(mpfr_exp_t)e,MPFR_RNDN))return 11;
  refconstant(id,rl,MPFR_RNDD);refconstant(id,ru,MPFR_RNDU);
  if(mpfr_cmp(lo,rl)>0||mpfr_cmp(ru,hi)>0){fprintf(stderr,"enclosure id=%d p=%u\n",id,p);return 12;}
  if(count++)puts(",");
  gmp_printf("{\"id\":%d,\"p\":%u,\"e\":%ld,\"lo\":\"%Zx\",\"hi\":\"%Zx\",\"mpfr_directed_enclosure_inside\":true}",id,p,(long)e,l,u);
  ppf_context_init(&ctx);ppf_init2_ctx(&x,p,&ctx);mpfr_inits2(p,got,rr,down,up,(mpfr_ptr)0);
  for(int r=0;r<6;r++){
   ppf_context_flags_clear(&ctx,PPF_FLAGS_ALL);int t=libconstant(id,&x,(ppf_rnd_t)r,&ctx);
   if(t==PPF_TERNARY_ERROR)return 13;
   ppf_exp_t ze=ppf_get_z_2exp(z,&x);if(mpfr_set_z_2exp(got,z,ze,MPFR_RNDN))return 14;
   if(r==5){refconstant(id,down,MPFR_RNDD);refconstant(id,up,MPFR_RNDU);if(!mpfr_equal_p(got,down)&&!mpfr_equal_p(got,up))return 15;}
   else {int rt=refconstant(id,rr,(mpfr_rnd_t)r);if(!mpfr_equal_p(got,rr)||signum(t)!=signum(rt)){fprintf(stderr,"round id=%d p=%u r=%d\n",id,p,r);return 16;}}
   if(!(ppf_context_flags(&ctx)&PPF_FLAG_INEXACT))return 17;
   rounds++;
  }
  ppf_clear(&x);ppf_context_clear(&ctx);mpfr_clears(lo,hi,rl,ru,got,rr,down,up,(mpfr_ptr)0);
 }
 printf("\n],\"interval_count\":%d,\"rounding_count\":%d,\"passed\":true}\n",count,rounds);
 mpz_clears(l,u,z,NULL);ppf_free_constant_caches();mpfr_free_cache();return 0;
}
