from pathlib import Path
from fractions import Fraction as F
import hashlib,json,platform,subprocess,datetime,time,sys
ROOT=Path(__file__).resolve().parent; PROJECT=ROOT.parent.parent/'work/polyphase-float'; LIB=ROOT/'build/libpolyphase_float.a'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
inputs=[*sorted((PROJECT/'src').glob('*.[ch]')),*sorted((PROJECT/'include').glob('*.h')),LIB,ROOT/'probe_constants.c',Path(__file__).resolve(),Path('/usr/include/mpfr.h'),Path('/usr/lib/x86_64-linux-gnu/libmpfr.so.6.2.1'),Path('/usr/lib/x86_64-linux-gnu/libgmp.so.10.5.0')]
inputs=[p for p in inputs if p.is_file()];before={str(p):digest(p) for p in inputs};start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
cmd=['cc','-O2','-std=c11','-Wall','-Wextra','-Werror','-I'+str(PROJECT/'include'),str(ROOT/'probe_constants.c'),str(LIB),'-lmpfr','-lgmp','-lm','-pthread','-o',str(ROOT/'probe_constants')]
subprocess.run(cmd,check=True,capture_output=True)
with (ROOT/'constants_results.json').open('w') as out, (ROOT/'constants_stderr.log').open('w') as err:
 run=subprocess.run([str(ROOT/'probe_constants')],stdout=out,stderr=err,timeout=300)
if run.returncode:raise RuntimeError('C probe failed: '+str(run.returncode))
data=json.loads((ROOT/'constants_results.json').read_text());Q=2600;target=F(1,1<<Q)
def atan_unit(q):
 s=F(0);k=0
 while True:
  term=F(1,(2*k+1)*q**(2*k+1));s+=term if k%2==0 else -term;k+=1
  rem=F(1,(2*k+1)*q**(2*k+1))
  if rem<target:return (s-rem,s,k) if k%2 else (s,s+rem,k)
a,b,na=atan_unit(5);c,d,nb=atan_unit(239);pi=(16*a-4*d,16*b-4*c)
s=F(0);n=0
while True:
 s+=F(2,3*(2*n+1)*9**n);n+=1;tail=F(3,4*(2*n+1)*9**n)
 if tail<target:break
log2=(s,s+tail);exact=[]
for item in data['intervals']:
 if item['id'] not in (1,2):continue
 scale=F(2)**item['e'];lo=int(item['lo'],16)*scale;hi=int(item['hi'],16)*scale;r=pi if item['id']==1 else log2
 assert lo<=r[0]<=r[1]<=hi,(item['id'],item['p'])
 exact.append({'id':item['id'],'p':item['p'],'independent_rational_enclosure_inside':True})
res={'passed':True,'exact_rational_enclosure_count':len(exact),'machin_atan_terms':[na,nb],'log2_terms':n,'reference_target_bits':Q,'checks':exact,'non_claim':'Finite implementation checks, not universal correct-rounding proof or outside reproduction.'}
(ROOT/'exact_rational_results.json').write_text(json.dumps(res,indent=2)+'\n')
after={str(p):digest(p) for p in inputs};assert before==after
outputs=[ROOT/'constants_results.json',ROOT/'exact_rational_results.json',ROOT/'constants_stderr.log',ROOT/'probe_constants']
manifest={'schema_version':2,'claim_id':'core-constants-finite-enclosures','repository':{'commit':'70ce732e2244effcd7bd0d450618e5734546a2b8','dirty':True},'command':[sys.executable,str(Path(__file__).resolve())],'environment':{'software':[{'name':'Python','version':platform.python_version()},{'name':'cc','version':subprocess.check_output(['cc','--version'],text=True).splitlines()[0]},{'name':'GMP','version':data['gmp']},{'name':'MPFR','version':data['mpfr']}],'hardware':platform.platform()+' '+platform.machine()},'mathematics':{'assertion_tested':'All 64 exported constant intervals contain both high-precision MPFR directed bounds; 384 constant rounding calls agree in value/ternary except faithful mode allows either adjacent value. All 32 pi/log2 intervals also contain independent exact-rational reference enclosures.','coefficient_domain':'GMP integers, Python Fraction rationals, directed MPFR binary floating point','conventions':'Closed intervals; ppf rounding modes 0..5; faithful admits either directed neighbor. Exact rational pi uses Machin alternating arctangent bounds; log2 uses direct rational series and geometric tail.','inputs':list(range(1,5)),'bounds':{'precisions':[2,3,5,24,53,63,64,65,113,127,128,129,257,512,1024,2048],'workers':1,'reference_exact_bits':2600},'non_claims':['Not universal numerical proof.','MPFR-dependent checks are conditional on MPFR.','Does not provide external reproduction or independent outside human review.','No concurrency or allocation-failure testing.']},'randomness':{'used':False,'generator':'','seed':None},'run':{'started_at':start,'runtime_seconds':time.monotonic()-t,'exit_status':0,'status':'completed','resource_limits':{'memory_bytes':None,'cpu_seconds':None,'max_cores':None,'max_threads':1}},'outputs':[{'path':str(p.relative_to(ROOT.parent.parent)),'sha256':digest(p),'kind':'result' if p.suffix=='.json' else 'log'} for p in outputs],'checks':['Source, headers, static library, test harness, oracle library and runner hashes unchanged before/after.','Exact-conversion MPFR setup rejects unexpected rounding.','Enclosure direction checked at higher precision than exported endpoints.','C harness rebuilt with -Werror.'],'result':'implementation and finite assertion verified in the stated range','residual_risks':['Same execution environment as other qualification; not outside reproduction.','Pi/log2 rational references share known mathematical identities but use separate algorithms from packet code.','Euler/Catalan probes depend on MPFR; their mathematical tails reviewed separately.'],'input_artifacts':[{'path':str(Path(p).relative_to(ROOT.parent.parent)),'sha256':before[p],'sha256_after':after[p]} for p in before if Path(p).is_relative_to(ROOT.parent.parent)],'declared_results':['qualification/core_math/constants_results.json','qualification/core_math/exact_rational_results.json'],'external_dependency_hashes':[{'path':p,'sha256':before[p],'sha256_after':after[p]} for p in before if not Path(p).is_relative_to(ROOT.parent.parent)],'compile_command':cmd}
(ROOT/'COMPUTATION_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'passed':True,'intervals':data['interval_count'],'roundings':data['rounding_count'],'exact_rational':len(exact),'seconds':manifest['run']['runtime_seconds']}))
