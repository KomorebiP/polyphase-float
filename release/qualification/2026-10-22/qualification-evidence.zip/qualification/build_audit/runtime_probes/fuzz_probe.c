#include <stddef.h>
#include <stdint.h>
int LLVMFuzzerTestOneInput(const uint8_t *p,size_t n){(void)p;(void)n;return 0;}
