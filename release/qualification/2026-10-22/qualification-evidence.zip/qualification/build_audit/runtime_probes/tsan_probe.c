#include <pthread.h>
static void *f(void *p){return p;}
int main(void){pthread_t t; if(pthread_create(&t,0,f,0))return 1; return pthread_join(t,0);}
