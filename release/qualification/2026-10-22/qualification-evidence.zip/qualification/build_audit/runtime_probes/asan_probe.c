#include <stdlib.h>
int main(void){char *p=malloc(10); if(!p)return 1; p[9]=3; int r=p[9]-3; free(p); return r;}
