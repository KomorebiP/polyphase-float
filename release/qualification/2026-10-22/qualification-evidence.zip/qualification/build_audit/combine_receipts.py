#!/usr/bin/env python3
"""Bind final qualification to exact receipts and retain failed attempts explicitly."""
import hashlib,json,re
from pathlib import Path
Q=Path(__file__).resolve().parents[1]
paths={'initial_matrix':Q/'final_matrix/qualification_20261022T215435_286909Z/qualification.json','openmp_replacement':Q/'final_openmp_retry/qualification_20261022T220128_724758Z/qualification.json','asan_recovery':Q/'final_asan_recovery/qualification.json','fuzz':Q/'final_fuzz/qualification_20261022T215417_423257Z/qualification.json','supplemental':Q/'final_supplemental/supplemental.json'}
r={k:json.loads(p.read_text()) for k,p in paths.items()}
snapshots={k:(v['source_snapshot'] if k=='supplemental' else json.loads((paths[k].parent/'source_snapshot.json').read_text())) for k,v in r.items()}
frozen=json.loads((Q/'SOURCE_SNAPSHOT_FINAL.json').read_text())
same=all(v==frozen for v in snapshots.values())
checks={scope:r['initial_matrix']['scopes'][scope] for scope in ('gcc-serial','clang-serial')}
checks['gcc-openmp']=r['openmp_replacement']['scopes']['gcc-openmp']
checks['asan']=r['asan_recovery']['scopes']['asan']
checks['fuzz']=r['fuzz']['scopes']['fuzz']
checks['supplemental']={'status':r['supplemental']['status'],'steps':r['supplemental']['steps']}
skipped=[]
selected={'initial_matrix':('gcc-serial','clang-serial'),'openmp_replacement':('gcc-openmp',),'asan_recovery':('asan',),'fuzz':('fuzz',)}
fuzz_summary={}
for key,scopes in selected.items():
 for scope in scopes:
  for step in r[key]['scopes'][scope]['steps']:
   log=paths[key].parent/step['log'];text=log.read_text(errors='replace')
   if step['name']=='ctest':
    skipped.extend({'scope':scope,'line':line} for line in text.splitlines() if re.search(r'Skipped|Not Run|DISABLED',line))
   if scope=='fuzz' and step['name'] in ('text','fpif'):
    done=re.findall(r'Done (\d+) runs in (\d+) second',text)
    counters=[int(x) for x in re.findall(r'^#(\d+)\s',text,re.M)]
    artifacts=paths[key].parent/'artifacts'/step['name']
    fuzz_summary[step['name']]={'exit_code':step['exit_code'],'elapsed_seconds':step['elapsed_seconds'],'requested_seconds':600,'final_run_count':int(done[-1][0]) if done else None,'observed_run_count_lower_bound':max(counters) if counters else None,'final_footer_present':bool(done),'crash_artifacts':sorted(p.name for p in artifacts.iterdir()),'log':str(log),'log_sha256':step['log_sha256']}
for step in r['supplemental']['steps']:
 if step.get('tests'):
  text=(paths['supplemental'].parent/step['log']).read_text(errors='replace')
  skipped.extend({'scope':'supplemental/'+step['name'],'line':line} for line in text.splitlines() if re.search(r'Skipped|Not Run|DISABLED',line))
initial=r['initial_matrix']
preserved=[{'scope':s,'status':initial['scopes'][s]['status'],'reason':reason,'receipt':str(paths['initial_matrix']),'ctest_log':str(paths['initial_matrix'].parent/'logs'/s/'ctest.log')} for s,reason in [('gcc-openmp','72 tests passed; range_flags could not execute because its generated ELF had mode0644. A new clean configuration/build then passed all73 tests.'),('asan','29 tests passed; io_allocation_failure could not execute because its generated ELF had mode0644. Only its execute bits were restored, byte hashes remained identical, and the omitted test passed in a distinct retry. Aggregate coverage is30 distinct planned tests across both attempts.')]]
mode_receipts=[paths['initial_matrix'].parent/'OPENMP_EXECUTION_MODE_FAILURE.json',paths['initial_matrix'].parent/'ASAN_EXECUTION_MODE_REPAIR.json']
all_fuzz=all(x['exit_code']==0 and x['elapsed_seconds']>=600 and not x['crash_artifacts'] for x in fuzz_summary.values())
passed=all(x['status']=='PASS' for x in checks.values()) and same and all(v.get('source_unchanged') for v in r.values()) and not skipped and all_fuzz and r['asan_recovery']['compiled_artifacts_unchanged']
report={'schema':'polyphase-float.combined-local-qualification/1','status':'PASS' if passed else 'FAIL','source':initial['source'],'source_version':initial['source_version'],'source_commit':'ba82abe7cff3b77ba4d2b07833bcfda953e92a2c','source_snapshot_files':len(frozen),'source_snapshot_sha256':hashlib.sha256((Q/'SOURCE_SNAPSHOT_FINAL.json').read_bytes()).hexdigest(),'all_receipts_bind_identical_frozen_source':same,'all_receipts_source_unchanged':all(v.get('source_unchanged') for v in r.values()),'required_matrix_complete_across_preserved_receipts':all(checks[x]['status']=='PASS' for x in ('gcc-serial','clang-serial','gcc-openmp')),'checks':checks,'fuzz_campaigns':fuzz_summary,'active_scope_skipped_markers':skipped,'preserved_failed_attempts':preserved,'execution_mode_receipts':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in mode_receipts],'archive_sha256':r['supplemental']['archive_sha256'],'archive_members':r['supplemental']['archive_members'],'core_needed_libraries':r['supplemental']['core_needed_libraries'],'receipts':{k:{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for k,p in paths.items()},'tools':initial['tools'],'limits':['Local Linux x86_64 execution; not independent external replication, other-platform support or universal mathematical correctness.','ASan/UBSan and fuzz use ASAN_OPTIONS=detect_leaks=0:abort_on_error=1; LeakSanitizer was disabled.','ASan excludes the Python ctypes ABI export test; all three ordinary final compiler scopes execute it.','ASan covers30 distinct planned hardening tests across preserved29-pass attempt and one formerly unexecuted test retry with unchanged compiled bytes.','Two generated executables unexpectedly had non-executable modes; cause remains unidentified. Both initial failures and recovery evidence are preserved.','Both fuzz targets exited0 after601.065seconds with no crash artifacts. Text log lacks its final footer;161552 is an observed lower bound, not an exact total.','Fuzz scope is the text-parser and PPFIF harnesses with fixed recorded seeds and bounded input models.','Archive reproducibility is same-environment source-archive byte equality, not cross-platform binary reproducibility.']}
output=Q/'BUILD_QUALIFICATION_FINAL.json'
output.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':report['status'],'report':str(output),'source_snapshot_sha256':report['source_snapshot_sha256'],'fuzz_campaigns':fuzz_summary},indent=2))
raise SystemExit(0 if passed else 1)
