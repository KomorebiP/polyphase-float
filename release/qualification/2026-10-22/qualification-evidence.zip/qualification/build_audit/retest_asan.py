#!/usr/bin/env python3
"""Run the sole previously unexecuted ASan test after an executable-mode repair."""
import argparse, importlib.util, json, os, re, sys
from pathlib import Path
from types import SimpleNamespace
sys.dont_write_bytecode=True
ap=argparse.ArgumentParser()
ap.add_argument('--source',type=Path,required=True)
ap.add_argument('--original-run',type=Path,required=True)
ap.add_argument('--output',type=Path,required=True)
a=ap.parse_args()
source=a.source.resolve(); output=a.output.resolve(); original=a.original_run.resolve()
output.mkdir(parents=True,exist_ok=False)
spec=importlib.util.spec_from_file_location('q',source/'tools/qualify_release.py');q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
previous=json.loads((original/'qualification.json').read_text())
initial_log=(original/'logs/asan/ctest.log').read_text()
initial_passes=re.findall(r'^\s*\d+/\d+ Test\s+#\d+:\s+(\S+)\s+\.+\s+Passed',initial_log,re.M)
initial_failures=[line for line in initial_log.splitlines() if '***' in line]
if len(initial_passes)!=29 or len(initial_failures)!=1 or not ('io_allocation_failure' in initial_failures[0] and '***Not Run' in initial_failures[0]):
 raise RuntimeError('Initial ASan attempt is not exactly29passes plus the known mode-only omission; investigate before a partial retry.')
before=q.snapshot(source)
q.write_json(output/'source_snapshot.json',before)
build=original/'build/asan'
def binaries():
 return {p.name:q.digest(p) for p in sorted(build.iterdir()) if p.is_file() and (p.name.startswith(('test_','example_','libpolyphase','abi_layout')))}
artifact_before=binaries()
qualification=q.Qualification(source,output,SimpleNamespace(detect_leaks=0))
r=qualification.receipt
r.update(source_version=previous['source_version'],selected_scopes=['asan'],tools=previous['tools'],source_snapshot_files=len(before),source_snapshot_sha256=q.digest(output/'source_snapshot.json'),retest_reason='Initial complete selection could not execute test_io_allocation_failure because the generated ELF lost execute bits. Only owned artifact mode was restored; bytes unchanged. Only the previously unexecuted test is retried, then combined with29 distinct completed tests from the unchanged instrumented build; original scope failure remains preserved.',prior_failed_receipt=str(original/'qualification.json'),mode_repair_receipt=str(original/'ASAN_EXECUTION_MODE_REPAIR.json'),compiled_artifacts_before=artifact_before)
for scope in q.SCOPES:r['scopes'][scope]={'status':'NOT_RUN','required':scope in q.REQUIRED,'reason':'Not selected for this retest'}
step=qualification.step('asan','ctest',['ctest','--test-dir',str(build),'--output-on-failure','--no-tests=error','-j1','-R','^io_allocation_failure$'],environment={'ASAN_OPTIONS':'detect_leaks=0:abort_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'})
r['scopes']['asan']={'status':step['status'],'required':False,'steps':[step],'dependencies':previous['scopes']['asan']['dependencies'],'reused_configure_and_build_from':str(original/'qualification.json'),'initial_passed_test_names':initial_passes,'retry_test_names':['io_allocation_failure'],'aggregate_test_counts':{'total':30,'passed':29+(1 if step['status']=='PASS' else 0),'failed_or_unexecuted':0 if step['status']=='PASS' else 1},'aggregation_note':'29 distinct planned tests passed in the preserved initial attempt; the sole permission-blocked test passed after mode-only repair of unchanged bytes.'}
after=q.snapshot(source)
r['changed_source_paths']=sorted(k for k in before.keys()|after.keys() if before.get(k)!=after.get(k))
r['source_unchanged']=not r['changed_source_paths']
r['compiled_artifacts_after']=binaries()
r['compiled_artifacts_unchanged']=artifact_before==r['compiled_artifacts_after']
r['completed_scopes']=['asan'] if step['status']=='PASS' else []
r['required_matrix_complete']=False
r['status']='PASS_COMPLETED_SCOPES' if step['status']=='PASS' and r['source_unchanged'] and r['compiled_artifacts_unchanged'] else 'FAIL'
r['completed_utc']=q.utc_now()
q.write_json(output/'qualification.json',r)
print(json.dumps({'status':r['status'],'receipt':str(output/'qualification.json')},indent=2))
raise SystemExit(0 if r['status']=='PASS_COMPLETED_SCOPES' else 1)
