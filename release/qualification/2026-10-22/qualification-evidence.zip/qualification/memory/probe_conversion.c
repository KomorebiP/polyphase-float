#include "polyphase_float.h"
#include <stdio.h>
#include <stdlib.h>
static size_t largest;
static void *a(size_t n){if(n>largest)largest=n;if(n>65536){fprintf(stderr,"conversion requested %zu bytes\n",n);exit(77);}return malloc(n);}
static void *r(void*p,size_t old,size_t n){(void)old;if(n>largest)largest=n;if(n>65536){fprintf(stderr,"conversion requested %zu bytes\n",n);exit(77);}return realloc(p,n);}
static void f(void*p,size_t n){(void)n;free(p);}
int main(void){ppf_context_t ctx;ppf_t x;mp_set_memory_functions(a,r,f);ppf_context_init(&ctx);ppf_init2_ctx(&x,128,&ctx);ppf_set_ui(&x,1,PPF_RNDN,&ctx);ppf_set_exp(&x,-1000000000,&ctx);double d=ppf_get_d(&x,PPF_RNDN,&ctx);printf("d=%g largest=%zu\n",d,largest);ppf_clear(&x);ppf_context_clear(&ctx);ppf_thread_cleanup();return 0;}
