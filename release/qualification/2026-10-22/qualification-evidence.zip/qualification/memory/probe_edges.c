#include "polyphase_float.h"
#include "special_internal.h"
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static int fail_now;
static void *a(void *o, size_t n) { (void)o; return fail_now ? NULL : malloc(n); }
static void *r(void *o, void *p, size_t old, size_t n) { (void)o; (void)old; return fail_now ? NULL : realloc(p,n); }
static void f(void *o, void *p, size_t n) { (void)o;(void)n;free(p); }
int main(int argc, char **argv) {
 ppf_context_t ctx; ppf_t x; ppf_exp_t e=0; char *s;
 if(argc<2)return 2;
 if(!strcmp(argv[1],"ndigits")){printf("%zu\n",ppf_get_str_ndigits(INT_MIN,128));return 0;}
 if(!strcmp(argv[1],"iv_abs")){
  ppf_allocator_t alloc={a,r,f,NULL};ppf_special_iv_t in,out;
  ppf_context_init_custom(&ctx,&alloc);ppf_special_iv_init(&in,128,&ctx);ppf_special_iv_init(&out,128,&ctx);
  ppf_set_si(&in.lo,-1,PPF_RNDN,&ctx);ppf_set_ui(&in.hi,1,PPF_RNDN,&ctx);fail_now=1;
  printf("rc=%d\n",ppf_special_iv_abs(&out,&in,&ctx));fail_now=0;
  ppf_special_iv_clear(&in);ppf_special_iv_clear(&out);ppf_context_clear(&ctx);return 0;
 }
 ppf_context_init(&ctx);ppf_init2_ctx(&x,128,&ctx);ppf_set_zero(&x,-1);
 if(!strcmp(argv[1],"base")){s=ppf_get_str(NULL,&e,INT_MIN,0,&x,PPF_RNDN,&ctx);ppf_free_str(s);}
 if(!strcmp(argv[1],"zero_digits")){s=ppf_get_str(NULL,&e,10,SIZE_MAX,&x,PPF_RNDN,&ctx);ppf_free_str(s);}
 ppf_clear(&x);ppf_context_clear(&ctx);ppf_thread_cleanup();return 0;
}
