/* Independent bounded probe; no production sources or project test helpers reused. */
#include "polyphase_float.h"
#include <mpfr.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv) {
    ppf_context_t ctx;
    ppf_t x, result;
    mpfr_t mx, expected;
    if (argc != 3) return 2;
    long exponent = strtol(argv[2], NULL, 10);
    unsigned long precision = strcmp(argv[1], "retry") == 0 ? 32768UL : 128UL;
    if (ppf_context_init(&ctx) || ppf_init2_ctx(&x, precision, &ctx) ||
        ppf_init2_ctx(&result, 53, &ctx)) return 3;
    mpfr_init2(mx, precision); mpfr_init2(expected, 53);
    int rc;
    if (strcmp(argv[1], "retry") == 0) {
        if (ppf_set_si_2exp(&x, -1, -1, PPF_RNDN, &ctx)) return 4;
        mpfr_set_si_2exp(mx, -1, -1, MPFR_RNDN);
    } else {
        if (ppf_set_ui_2exp(&x, 1, exponent, PPF_RNDN, &ctx)) return 4;
        mpfr_set_ui_2exp(mx, 1, exponent, MPFR_RNDN);
    }
    ppf_set_ui(&result, 17, PPF_RNDN, &ctx);
    ppf_context_flags_clear(&ctx, PPF_FLAGS_ALL);
    fprintf(stderr, "begin function=%s input=2^%ld input_precision=%lu output_precision=53\n",
            argv[1], exponent, precision); fflush(stderr);
    if (strcmp(argv[1], "retry") == 0) rc = ppf_zeta(&result, &x, PPF_RNDN, &ctx);
    else if (strcmp(argv[1], "gamma") == 0) rc = ppf_gamma(&result, &x, PPF_RNDN, &ctx);
    else if (strcmp(argv[1], "lgamma") == 0) rc = ppf_lngamma(&result, &x, PPF_RNDN, &ctx);
    else return 5;
    printf("{\"function\":\"%s\",\"input_power\":%ld,\"input_precision\":%lu,"
           "\"return\":%d,\"kind\":%d,\"sign\":%d,\"flags\":%u,\"valid\":%d,"
           "\"preserved_17\":%d}\n", argv[1], exponent, precision, rc,
           (int)result.kind, result.sign, (unsigned)ctx.flags, ppf_validate(&result),
           ppf_number_p(&result) && ppf_cmp_ui(&result,17,&ctx)==0);
    fflush(stdout);
    mpfr_clear_flags();
    int mr = strcmp(argv[1],"retry")==0 ? mpfr_zeta(expected,mx,MPFR_RNDN) :
             strcmp(argv[1],"gamma")==0 ? mpfr_gamma(expected,mx,MPFR_RNDN) :
             mpfr_lngamma(expected,mx,MPFR_RNDN);
    mpfr_printf("oracle=%Ra return=%d overflow=%d underflow=%d inexact=%d\n",
                expected,mr,mpfr_overflow_p()!=0,mpfr_underflow_p()!=0,mpfr_inexflag_p()!=0);
    ppf_clear(&x);ppf_clear(&result);ppf_context_clear(&ctx);
    mpfr_clear(mx);mpfr_clear(expected);
    return 0;
}
