#define _GNU_SOURCE
#include <execinfo.h>
#include <signal.h>
#include <unistd.h>
#define main numerical_main
#include "probe_extreme.c"
#undef main
static void trace_signal(int signal_number) {
    void *frames[32];
    int count = backtrace(frames,32);
    backtrace_symbols_fd(frames,count,STDERR_FILENO);
    _exit(128 + signal_number);
}
int main(int argc,char **argv) {
    signal(SIGFPE,trace_signal);
    signal(SIGABRT,trace_signal);
    fprintf(stderr,"GMP %s; MPFR %s\n",gmp_version,mpfr_get_version());
    return numerical_main(argc,argv);
}
