#define main inherited_release_boundary_main
#include "/workspace/scratch/42e078a3c9ea/polyphase_release/work/polyphase-float/tests/test_special_edge_audit.c"
#undef main

static void range_case(const char *name, ppf_unary_fn pf, mpfr_unary_fn mf,
                       const char *text, ppf_exp_t emin, ppf_exp_t emax) {
    ppf_context_t ctx;
    ppf_t x, result;
    mpfr_t mx, actual, expected;
    mpfr_exp_t saved_min=mpfr_get_emin(), saved_max=mpfr_get_emax();
    CHECK(ppf_context_init(&ctx)==0);
    CHECK(ppf_init2_ctx(&x,128,&ctx)==0);
    CHECK(ppf_init2_ctx(&result,53,&ctx)==0);
    mpfr_init2(mx,128); mpfr_inits2(53,actual,expected,(mpfr_ptr)0);
    CHECK(mpfr_set_str(mx,text,0,MPFR_RNDN)==0);
    CHECK(ppf_set_mpfr(&x,mx,PPF_RNDN,&ctx)==0);
    ctx.emin=emin;ctx.emax=emax;
    for(unsigned k=0;k<5;++k){
        CHECK(mpfr_set_emin(emin)==0);CHECK(mpfr_set_emax(emax)==0);
        ppf_context_flags_clear(&ctx,PPF_FLAGS_ALL);mpfr_clear_flags();
        int a=pf(&result,&x,pr[k],&ctx),b=mf(expected,mx,mr[k]);
        ppf_flags_t flags=oracle_flags();
        CHECK(ppf_get_mpfr(actual,&result,MPFR_RNDN)!=PPF_TERNARY_ERROR);
        if(a==PPF_TERNARY_ERROR||signum(a)!=signum(b)||!same(actual,expected)||ctx.flags!=flags){
            fprintf(stderr,"range %s(%s) emin=%lld emax=%lld mode=%u ternary=%d/%d flags=%u/%u\n",name,text,(long long)emin,(long long)emax,k,a,b,ctx.flags,flags);
            mpfr_printf("actual=%Ra expected=%Ra\n",actual,expected);exit(1);
        }
        ++cases;
        CHECK(mpfr_set_emin(saved_min)==0);CHECK(mpfr_set_emax(saved_max)==0);
    }
    ppf_clear(&x);ppf_clear(&result);ppf_context_clear(&ctx);mpfr_clears(mx,actual,expected,(mpfr_ptr)0);
}
int main(void){
    range_case("Gamma",ppf_gamma,mpfr_gamma,"0x1p56",PPF_EMIN_MIN,PPF_EMAX_MAX);
    range_case("Gamma",ppf_gamma,mpfr_gamma,"-72057594037927935.5",PPF_EMIN_MIN,PPF_EMAX_MAX);
    range_case("Gamma",ppf_gamma,mpfr_gamma,"-72057594037927936.5",PPF_EMIN_MIN,PPF_EMAX_MAX);
    range_case("exp",ppf_exp,mpfr_exp,"0x1p62",PPF_EMIN_MIN,PPF_EMAX_MAX);
    range_case("exp",ppf_exp,mpfr_exp,"-0x1p62",PPF_EMIN_MIN,PPF_EMAX_MAX);
    range_case("exp",ppf_exp,mpfr_exp,"1",-20,-4);
    range_case("exp",ppf_exp,mpfr_exp,"-1",4,20);
    ppf_free_constant_caches();mpfr_mp_memory_cleanup();
    printf("extreme/narrow context comparisons passed: %lu; GMP=%s MPFR=%s\n",cases,gmp_version,mpfr_get_version());return 0;
}
