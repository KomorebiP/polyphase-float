#include "polyphase_float.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void cap(size_t size){if(size>4u*1024u*1024u){fprintf(stderr,"GMP request blocked: %zu bytes\n",size);fflush(stderr);_Exit(90);}}
static void *alloc(size_t size){cap(size);void*p=malloc(size);if(!p)_Exit(91);return p;}
static void *resize(void*p,size_t old,size_t size){(void)old;cap(size);p=realloc(p,size);if(!p)_Exit(91);return p;}
static void release(void*p,size_t size){(void)size;free(p);}
int main(int argc,char**argv){
 if(argc!=4)return 2;mp_set_memory_functions(alloc,resize,release);
 ppf_context_t c;ppf_t x,r;if(ppf_context_init(&c)||ppf_init2_ctx(&x,128,&c)||ppf_init2_ctx(&r,53,&c))return 3;
 int sign=atoi(argv[2]);long exponent=strtol(argv[3],NULL,10);if(ppf_set_si_2exp(&x,sign,exponent,PPF_RNDN,&c))return 4;
 ppf_context_flags_clear(&c,PPF_FLAGS_ALL);int t;
 if(!strcmp(argv[1],"exp2"))t=ppf_exp2(&r,&x,PPF_RNDN,&c);
 else if(!strcmp(argv[1],"exp10"))t=ppf_exp10(&r,&x,PPF_RNDN,&c);
 else if(!strcmp(argv[1],"exp2m1"))t=ppf_exp2m1(&r,&x,PPF_RNDN,&c);
 else if(!strcmp(argv[1],"expm1"))t=ppf_expm1(&r,&x,PPF_RNDN,&c);
 else if(!strcmp(argv[1],"exp10m1"))t=ppf_exp10m1(&r,&x,PPF_RNDN,&c);else return 5;
 printf("%s sign=%d return=%d kind=%d result_sign=%d flags=%u valid=%d\n",argv[1],sign,t,r.kind,r.sign,c.flags,ppf_validate(&r));
 if(!strcmp(argv[1],"exp2")&&exponent==60){if(sign>0){if(!ppf_inf_p(&r)||t!=1||c.flags!=(PPF_FLAG_OVERFLOW|PPF_FLAG_INEXACT))return 6;}else if(!ppf_zero_p(&r)||t!=-1||c.flags!=(PPF_FLAG_UNDERFLOW|PPF_FLAG_INEXACT))return 7;}else if(!ppf_nan_p(&r)||t!=PPF_TERNARY_ERROR||c.flags!=PPF_FLAG_ERANGE)return 8;
 ppf_clear(&r);ppf_clear(&x);ppf_context_clear(&c);ppf_free_constant_caches();return 0;
}
