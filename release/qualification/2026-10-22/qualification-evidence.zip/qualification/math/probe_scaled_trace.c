#define main probe_main
#include "probe_scaled_alloc.c"
#undef main
#include <signal.h>
#include <execinfo.h>
static void trace(int s){void*f[40];int n=backtrace(f,40);backtrace_symbols_fd(f,n,2);_Exit(128+s);}
int main(int argc,char**argv){signal(SIGFPE,trace);return probe_main(argc,argv);}
