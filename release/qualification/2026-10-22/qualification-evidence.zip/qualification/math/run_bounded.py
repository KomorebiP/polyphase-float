#!/usr/bin/env python3
"""Run an independent numerical probe with retained outputs and input hashes."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import resource
import subprocess
import time

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[1] / 'work/polyphase-float'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--name', required=True)
    parser.add_argument('--seconds', type=int, default=20)
    parser.add_argument('--library', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command
    if command and command[0] == '--': command = command[1:]
    if not command: parser.error('command required')
    destination = HERE / args.name
    destination.mkdir(exist_ok=False)
    inputs = sorted(list((WORK / 'src').glob('*.[ch]')) + list((WORK / 'include').glob('*.h')))
    inputs += [args.library.resolve(), args.source.resolve(), Path(command[0]).resolve(), Path(__file__).resolve()]
    before = {str(path): digest(path) for path in inputs}
    memory = 1024 * 1024 * 1024
    def limits():
        resource.setrlimit(resource.RLIMIT_AS, (memory, memory))
        resource.setrlimit(resource.RLIMIT_CPU, (args.seconds, args.seconds + 1))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    env = os.environ.copy(); env['OMP_NUM_THREADS'] = '1'
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    tick = time.monotonic(); status = 'completed'; exit_status = None
    with (destination/'stdout.txt').open('wb') as stdout, (destination/'stderr.txt').open('wb') as stderr:
        try:
            result = subprocess.run(command, stdout=stdout, stderr=stderr, env=env,
                cwd=HERE, preexec_fn=limits, timeout=args.seconds + 5, check=False)
            exit_status = result.returncode
            if exit_status != 0: status = 'failed'
        except subprocess.TimeoutExpired:
            status = 'timeout'
    runtime = time.monotonic() - tick
    artifacts = [{'path': path, 'sha256': value, 'sha256_after': digest(Path(path))}
                 for path, value in before.items()]
    if any(item['sha256'] != item['sha256_after'] for item in artifacts): status = 'inputs-changed'
    outputs = [{'path': str((destination/name).resolve()), 'sha256':digest(destination/name), 'kind':'result'}
               for name in ('stdout.txt','stderr.txt')]
    manifest = {
        'schema_version':2, 'claim_id':args.name,
        'repository':{'commit':'','dirty':None,'source_identity':'parent-verified candidate 70ce732e; extracted source, no Git metadata used'},
        'command':command,
        'environment':{'software':[{'name':'Python','version':platform.python_version()},
            {'name':'C compiler','version':subprocess.check_output(['cc','--version'],text=True).splitlines()[0]}],
            'hardware':platform.platform()+' '+platform.machine(),'overrides':{'OMP_NUM_THREADS':'1'}},
        'mathematics':{'assertion_tested':'See retained independent C source and exact argv; this receipt records execution, not a universal proof.',
            'coefficient_domain':'exact dyadic PPF inputs; MPFR oracle where called','conventions':'named PPF rounding modes; ordinary Linux LP64/GMP64 model',
            'inputs':command[1:],'bounds':{'cpu_seconds':args.seconds,'memory_bytes':memory},
            'non_claims':['No universal numerical correctness conclusion','No independent external-host replication']},
        'randomness':{'used':False,'generator':'','seed':None},
        'run':{'started_at':started,'runtime_seconds':runtime,'exit_status':exit_status,'status':status,
            'resource_limits':{'memory_bytes':memory,'cpu_seconds':args.seconds,'max_cores':1,'max_threads':1}},
        'outputs':outputs,'checks':['Input artifacts hashed before and after execution'],
        'result':'Read stdout/stderr and exit status; a failing exit alone is not a mathematical counterexample.',
        'residual_risks':['GMP and MPFR are trusted external dependencies; their versions are reported by the numerical harness.'],
        'input_artifacts':artifacts,'declared_results':[item['path'] for item in outputs],
    }
    (destination/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'name':args.name,'status':status,'exit_status':exit_status,'seconds':round(runtime,3),
        'stdout':(destination/'stdout.txt').read_text(),'stderr':(destination/'stderr.txt').read_text()}),flush=True)

if __name__ == '__main__': main()
