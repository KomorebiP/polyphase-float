#include "polyphase_float.h"
void fragment(void) {
ppf_context_t ctx;
mpz_t lower, upper; ppf_exp_t exponent = 0; ppf_rnd_t rounding = PPF_RNDN; int ternary;
ppf_t result;
ppf_interval_status_t s = ppf_set_dyadic_interval(
    &result, lower, upper, exponent, rounding, &ternary, &ctx);

(void)s;
}
