# Outside-environment correctness reproduction

The exact candidate is **Polyphase Float 0.20.0, unreleased**, source commit
`0b551118e9664b4aff174b74ebe1579357995fa9`, tree
`dbc93e7d9f1c30f98585a372525dfe9422ad2d67`. It has not been promoted to 1.0.

| Identifier | SHA-256 |
|---|---|
| Source ZIP | `f5cfe8795df5f8b99b51928e512b0179396afabe7dbb79339d805726bdb84145` |
| Source TAR.GZ | `94119de405af959b8651904060970d9ec928c1571527c70e9ab78b3259dbe133` |
| Sorted source snapshot JSON, 736 files | `77f607231ff6deccfc6f974657f579c71889d6a1e42bef863576c07099919ed1` |

Use the delivered `SOURCE_SNAPSHOT.json` and archives. Verify `SHA256SUMS` in
the evidence directory, then extract the chosen source archive. Keep all
qualification output outside the extracted source directory. Do not edit
source or documentation before execution; a changed snapshot is a different
candidate.

The declared platform is Linux x86-64 ELF, LP64, with 64-bit GMP limbs.
The reference environment used GCC 13.3.0, Clang 18.1.3, CMake/CTest 3.28.3,
Python 3.12.14, GMP 6.3.0, and MPFR 4.2.1, with official development headers.
Install a working `pkg-config` and the compiler sanitizer runtimes. The GMP
core needs POSIX threads; MPFR supports the adapter and numerical test oracles;
GCC OpenMP supplies the selected parallel configuration. Record actual
versions and omissions when using a different conforming environment.

From the extracted `polyphase-float-0.20.0` directory:

```sh
python3 tools/release_audit.py --root .
python3 tools/qualify_release.py \
  --source . --output ../outside-qualification \
  --only gcc-serial clang-serial gcc-openmp asan fuzz \
  --fuzz-seconds 600 --fuzz-case-timeout 30 --fuzz-max-len 8192 \
  --text-seed 2026102201 --fpif-seed 2026102202 \
  --detect-leaks 0 --openmp-threads 4 --jobs 2
python3 tools/check_manual_examples.py \
  --source . --output ../outside-manual-examples --cc gcc clang --jobs 2
```

The qualifier writes a dated result directory with `qualification.json`,
`source_snapshot.json`, raw `logs/`, and build/installation records. Return
those receipts and raw logs, the complete generated fuzz corpus and any
failure artifacts, the command lines and exit statuses, and the actual host,
compiler, dependency, sanitizer and runtime settings. Hash retained corpora
and artifacts. Do not report a final fuzz execution count unless the log
contains one. Keep failed, interrupted, omitted and not-started checks visible.
LeakSanitizer is explicitly disabled above; it is not qualified by that command.
Additional package, ABI, benchmark and ThreadSanitizer records in the evidence
archive state their own tested scope and exclusions.

The promotion policy requires **two independent correctness reproductions in
outside environments** of this exact candidate and declared matrix. No
particular human identity or institution is required. Several compilers,
processes, agents or containers sharing the present environment remain local
evidence. A completed outside run must identify its independent environment
and exact source and retain contrary results; a job that never started does
not count.

These reproductions close only their named promotion requirement. Sustained
fuzz execution, complete required numerical-limit boundary evidence, complete
written arguments for every certified numerical path, and independent review
of rounding, constant arguments and intended claims remain separate
requirements. See `docs/ONE_POINT_ZERO_READINESS.md`,
`docs/NUMERICAL_LIMITS.md`, `docs/NUMERICAL_ARGUMENTS.md` and
`docs/CLAIMS_AND_EVIDENCE.md` in the source archive.
