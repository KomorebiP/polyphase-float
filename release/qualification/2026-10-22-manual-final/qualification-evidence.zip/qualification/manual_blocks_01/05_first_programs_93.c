#include "polyphase_float.h"
void fragment(void) {
ppf_context_t ctx;
int down, near, up;
ppf_t lower, nearest, upper, one, three;
down = ppf_div(&lower, &one, &three, PPF_RNDD, &ctx);
near = ppf_div(&nearest, &one, &three, PPF_RNDN, &ctx);
up = ppf_div(&upper, &one, &three, PPF_RNDU, &ctx);

(void)down; (void)near; (void)up;
}
