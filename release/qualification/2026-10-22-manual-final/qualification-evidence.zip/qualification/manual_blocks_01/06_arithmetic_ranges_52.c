#include "polyphase_float.h"
void fragment(void) {
ppf_context_t ctx;
ppf_t product, a, b;
int t = ppf_mul(&product, &a, &b, PPF_RNDN, &ctx);
if (t == PPF_TERNARY_ERROR) {
    /* Diagnose the failure; product is not a usable new answer. */
} else if (t == 0) {
    /* For an ordinary finite result, the multiplication is exact. */
} else {
    /* A valid rounded result; the sign of t gives its direction. */
}

(void)t;
}
