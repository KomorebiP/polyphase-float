#include "polyphase_float.h"
void fragment(void) {
ppf_context_t ctx;
ppf_t a, b;
int ternary = ppf_set(&b, &a, PPF_RNDN, &ctx);

(void)ternary;
}
