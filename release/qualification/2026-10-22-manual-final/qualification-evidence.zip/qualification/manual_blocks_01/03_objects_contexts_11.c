#include "polyphase_float.h"
int main(void) {
ppf_context_t ctx;
ppf_t x = {0};
int status = 1;

if (ppf_context_init(&ctx) != 0) return 1;
if (ppf_init2_ctx(&x, 128, &ctx) != 0) goto cleanup;
if (ppf_set_ui(&x, 7, PPF_RNDN, &ctx) == PPF_TERNARY_ERROR)
    goto cleanup;
status = 0;

cleanup:
ppf_clear(&x);
ppf_context_clear(&ctx);
return status;

return 0;
}
