#include "polyphase_float.h"
void fragment(void) {
ppf_context_t ctx;
mpz_t radicand, lower, upper, remainder; unsigned long k; int ternary;
ppf_t result;
mpz_set_ui(radicand, 2);
mpz_mul_2exp(radicand, radicand, 2u * k);
mpz_sqrtrem(lower, remainder, radicand);
mpz_add_ui(upper, lower, 1);

ppf_interval_status_t s = ppf_set_dyadic_interval(
    &result, lower, upper, -(ppf_exp_t)k,
    PPF_RNDN, &ternary, &ctx);

(void)s;
}
