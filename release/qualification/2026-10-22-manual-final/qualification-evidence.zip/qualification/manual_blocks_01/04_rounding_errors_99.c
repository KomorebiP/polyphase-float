#include "polyphase_float.h"
void fragment(void) {
ppf_context_t ctx;
ppf_t result, one, three;
ppf_context_flags_clear(&ctx, PPF_FLAGS_ALL);
int t = ppf_div(&result, &one, &three, PPF_RNDN, &ctx);
ppf_flags_t observed = ppf_context_flags(&ctx);

(void)t; (void)observed;
}
