#include "polyphase_float.h"
int main(void) {
ppf_context_t ctx;
ppf_t x = {0}, y = {0};

if (ppf_context_init(&ctx) != 0) return 1;
if (ppf_init2_ctx(&x, 128, &ctx) != 0 ||
    ppf_init2_ctx(&y, 128, &ctx) != 0) {
    ppf_clear(&y);
    ppf_clear(&x);
    ppf_context_clear(&ctx);
    return 1;
}
/* Assign values and perform checked calculations here. */
ppf_clear(&y);
ppf_clear(&x);
ppf_context_clear(&ctx);

return 0;
}
