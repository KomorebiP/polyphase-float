#include "polyphase_float.h"
void fragment(void) {
ppf_context_t ctx;
ppf_t quotient, numerator, denominator;
int t = ppf_div(&quotient, &numerator, &denominator,
                PPF_RNDN, &ctx);

(void)t;
}
