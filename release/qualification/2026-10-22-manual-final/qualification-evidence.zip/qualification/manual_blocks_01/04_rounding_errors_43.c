#include "polyphase_float.h"
void fragment(void) {
ppf_context_t ctx;
ppf_t result, numerator, denominator;
int t = ppf_div(&result, &numerator, &denominator,
                PPF_RNDN, &ctx);
if (t == PPF_TERNARY_ERROR) {
    /* Handle the failure; do not interpret t as a direction. */
} else if (t < 0) {
    /* The ordinary finite result is below its exact target. */
} else if (t > 0) {
    /* The ordinary finite result is above its exact target. */
} else {
    /* No inexact direction is reported; also check result category. */
}

(void)t;
}
