#include "polyphase_float.h"
void fragment(void) {
ppf_context_t ctx;
ppf_t value;
if (ppf_set_str(&value, "1.25", 10, PPF_RNDN, &ctx) != 0) {
    /* Report an invalid or unsuccessful conversion. */
}


}
