#include "polyphase_float.h"
void fragment(void) {
ppf_context_t ctx;
ppf_t decimal, native;
ppf_set_str(&decimal, "0.1", 10, PPF_RNDN, &ctx);
ppf_set_d(&native, 0.1, PPF_RNDN, &ctx);


}
