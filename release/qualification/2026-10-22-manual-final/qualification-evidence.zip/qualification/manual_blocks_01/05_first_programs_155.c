#include "polyphase_float.h"
void fragment(void) {
ppf_context_t ctx;
int ternary;
ppf_t coarse, fresh, widened;
if (ppf_set_str(&coarse, "0.1", 10, PPF_RNDN, &ctx) != 0 ||
    ppf_set_str(&fresh, "0.1", 10, PPF_RNDN, &ctx) != 0)
    goto cleanup;
ternary = ppf_set(&widened, &coarse, PPF_RNDN, &ctx);

(void)ternary; cleanup: return;
}
