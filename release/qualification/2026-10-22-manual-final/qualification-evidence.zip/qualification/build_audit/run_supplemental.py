#!/usr/bin/env python3
"""External qualification driver; never writes into the source tree."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import tarfile
import time
import zipfile

sys.dont_write_bytecode = True


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--build-gate', type=Path)
    args = parser.parse_args()
    source = args.source.resolve()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    if output == source or source in output.parents:
        raise RuntimeError('output must be outside source')
    logs = output / 'logs'
    logs.mkdir()
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    qualifier = load('qualification', source / 'tools/qualify_release.py')
    packager = load('packager', source / 'tools/create_source_release.py')
    env['SOURCE_DATE_EPOCH'] = str(packager.DEFAULT_EPOCH)
    before = qualifier.snapshot(source)
    receipt = {'status': 'RUNNING', 'source': str(source), 'started_utc': datetime.now(timezone.utc).isoformat(), 'scope': 'Linux x86_64 supplemental package, core independence, installed consumption, ABI and benchmark smoke checks.', 'steps': [], 'source_snapshot': before, 'source_date_epoch': env['SOURCE_DATE_EPOCH']}

    def save():
        (output / 'supplemental.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')

    def step(name, command, overrides=None):
        command = [str(x) for x in command]
        print(name + ': ' + shlex.join(command), flush=True)
        started = time.monotonic()
        log = logs / (name + '.log')
        with log.open('wb') as stream:
            proc = subprocess.run(command, cwd=output, env={**env, **(overrides or {})}, stdout=stream, stderr=subprocess.STDOUT)
        record = {'name': name, 'command': command, 'exit_code': proc.returncode, 'seconds': round(time.monotonic() - started, 3), 'log': str(log.relative_to(output)), 'log_sha256': digest(log)}
        match = re.search(r'(\d+)% tests passed, (\d+) tests failed out of (\d+)', log.read_text(errors='replace'))
        if match:
            record['tests'] = {'total': int(match[3]), 'failed': int(match[2]), 'passed': int(match[3])-int(match[2])}
        receipt['steps'].append(record)
        save()
        if proc.returncode:
            raise RuntimeError(name + ' failed: ' + str(log))
        return log.read_text(errors='replace')

    save()
    try:
        for name in ('archive_a', 'archive_b'):
            step(name, [sys.executable, source/'tools/create_source_release.py', '--root', source, '--output-dir', output/name])
        first, second = output/'archive_a', output/'archive_b'
        filenames = sorted(p.name for p in first.iterdir())
        hashes = {name: digest(first/name) for name in filenames}
        if any(hashes[name] != digest(second/name) for name in filenames):
            raise RuntimeError('repeated source packages differ')
        receipt['archive_sha256'] = hashes
        tar_path = next(first.glob('*.tar.gz'))
        zip_path = next(first.glob('*.zip'))
        files = packager.included_files(source, first)
        expected = {p.relative_to(source).as_posix(): digest(p) for p in files}
        with tarfile.open(tar_path) as tf, zipfile.ZipFile(zip_path) as zf:
            members = tf.getmembers()
            prefix = members[0].name.split('/')[0]
            tar_data = {}
            for member in members:
                relative = member.name.removeprefix(prefix + '/')
                if not member.isfile() or '..' in Path(relative).parts or Path(relative).is_absolute():
                    raise RuntimeError('unexpected archive member ' + member.name)
                tar_data[relative] = hashlib.sha256(tf.extractfile(member).read()).hexdigest()
            zip_data = {item.filename.removeprefix(prefix + '/'): hashlib.sha256(zf.read(item)).hexdigest() for item in zf.infolist()}
            if tar_data != expected or zip_data != expected:
                raise RuntimeError('source/archive content mismatch')
            extraction = output/'extracted'
            extraction.mkdir()
            tf.extractall(extraction, filter='data')
        extracted = extraction/prefix
        receipt['archive_members'] = len(expected)
        receipt['archive_contents_match_source'] = True
        receipt['archives_byte_reproducible_same_environment'] = True
        save()
        print('Archives verified: '+str(first), flush=True)
        if args.build_gate:
            print('Waiting for external build gate '+str(args.build_gate), flush=True)
            while not args.build_gate.exists():
                time.sleep(1)
        build = output/'build/core-off'
        prefix = output/'installed-core'
        step('core_configure', ['cmake','-S',extracted,'-B',build,'-DCMAKE_C_COMPILER=gcc','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_C_EXTENSIONS=OFF','-DPPF_WARNINGS_AS_ERRORS=ON','-DPPF_ENABLE_NATIVE_OPTIMIZATIONS=OFF','-DPPF_OPENMP=OFF','-DPPF_MPFR_SUPPORT=OFF','-DPPF_BUILD_SHARED=ON','-DPPF_BUILD_STATIC=ON','-DPPF_BUILD_EXAMPLES=ON','-DPPF_BUILD_BENCHMARKS=OFF','-DBUILD_TESTING=ON','-DCMAKE_INSTALL_LIBDIR=lib'])
        step('core_build', ['cmake','--build',build,'-j2'])
        step('core_ctest', ['ctest','--test-dir',build,'--output-on-failure','--no-tests=error','-j1'])
        library = build/'libpolyphase_float.so'
        step('core_release_audit', [sys.executable,extracted/'tools/release_audit.py','--root',extracted,'--library',library])
        step('core_independence', [sys.executable,extracted/'tools/audit_independence.py',library])
        dynamic = step('core_dynamic_dependencies', ['readelf','-d',library])
        needed = re.findall(r'\(NEEDED\).*?\[(.*?)\]', dynamic)
        if any(re.search(r'mpfr|gomp|libomp', name) for name in needed):
            raise RuntimeError('unexpected MPFR/OpenMP production dependency')
        receipt['core_needed_libraries'] = needed
        step('core_abi_exports', [sys.executable,extracted/'tools/abi_exports.py','--root',extracted,'--core-library',library,'--require-versions','--output',output/'core_abi_exports.json'])
        step('core_example', [build/'example_basic'])
        step('core_install', ['cmake','--install',build,'--prefix',prefix])
        for mode in ('shared','static'):
            cb = output/('consumer-'+mode)
            step(mode+'_consumer_configure', ['cmake','-S',extracted/'tests/install_consumer','-B',cb,'-DCMAKE_PREFIX_PATH='+str(prefix),'-DPPF_CONSUMER_COMPONENTS=core','-DCMAKE_DISABLE_FIND_PACKAGE_MPFR=TRUE','-DPPF_CONSUMER_FORCE_STATIC='+('ON' if mode=='static' else 'OFF')])
            step(mode+'_consumer_build', ['cmake','--build',cb,'-j2'])
            step(mode+'_consumer_ctest', ['ctest','--test-dir',cb,'--output-on-failure','--no-tests=error'])
        pkg_env = {'PKG_CONFIG_PATH': str(prefix/'lib/pkgconfig')}
        step('pkg_config_validate', ['pkg-config','--validate',prefix/'lib/pkgconfig/polyphase-float.pc'],pkg_env)
        flags = step('pkg_config_flags', ['pkg-config','--cflags','--libs','polyphase-float'],pkg_env)
        step('installed_example_compile', ['gcc','-std=c11','-Wall','-Wextra','-Werror',prefix/'share/doc/PolyphaseFloat/examples/basic.c','-o',output/'installed_example',*shlex.split(flags),'-Wl,-rpath,'+str(prefix/'lib')])
        step('installed_example_run', [output/'installed_example'])
        bench = output/'build/benchmark-smoke'
        step('benchmark_configure', ['cmake','-S',extracted,'-B',bench,'-DCMAKE_C_COMPILER=gcc','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_C_EXTENSIONS=OFF','-DPPF_WARNINGS_AS_ERRORS=ON','-DPPF_ENABLE_NATIVE_OPTIMIZATIONS=OFF','-DPPF_OPENMP=ON','-DPPF_MPFR_SUPPORT=ON','-DPPF_BUILD_BENCHMARKS=ON','-DPPF_BUILD_EXAMPLES=OFF','-DBUILD_TESTING=ON'])
        step('benchmark_build', ['cmake','--build',bench,'-j2'])
        step('benchmark_ctest', ['ctest','--test-dir',bench,'-L','smoke','--output-on-failure','--no-tests=error','-j1'],{'OMP_NUM_THREADS':'4'})
        tsan = output/'build/thread-sanitizer'
        step('tsan_configure', ['cmake','-S',extracted,'-B',tsan,'-DCMAKE_C_COMPILER=gcc','-DCMAKE_BUILD_TYPE=RelWithDebInfo','-DCMAKE_C_EXTENSIONS=OFF','-DPPF_WARNINGS_AS_ERRORS=ON','-DPPF_OPENMP=OFF','-DPPF_MPFR_SUPPORT=OFF','-DPPF_BUILD_SHARED=OFF','-DPPF_BUILD_STATIC=ON','-DPPF_BUILD_EXAMPLES=OFF','-DPPF_BUILD_BENCHMARKS=OFF','-DPPF_ENABLE_THREAD_SANITIZER=ON','-DBUILD_TESTING=ON'])
        step('tsan_build', ['cmake','--build',tsan,'--target','test_thread_safety','-j2'])
        step('tsan_ctest', ['ctest','--test-dir',tsan,'-L','threading','--output-on-failure','--no-tests=error','-j1'],{'TSAN_OPTIONS':'halt_on_error=1:history_size=7:second_deadlock_stack=1'})
        receipt['status'] = 'PASS'
    except BaseException as error:
        receipt['status'] = 'FAIL'
        receipt['error'] = str(error)
        raise
    finally:
        after = qualifier.snapshot(source)
        receipt['changed_source_paths'] = sorted(k for k in before.keys() | after.keys() if before.get(k) != after.get(k))
        receipt['source_unchanged'] = not receipt['changed_source_paths']
        if not receipt['source_unchanged']:
            receipt['status'] = 'FAIL'
        receipt['completed_utc'] = datetime.now(timezone.utc).isoformat()
        save()
        print(json.dumps({'status': receipt['status'], 'receipt': str(output/'supplemental.json')},indent=2),flush=True)
    return 0 if receipt['status']=='PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
