#!/usr/bin/env python3
"""Summarize final frozen-source receipts without rewriting failed raw executions."""
from datetime import datetime,timezone
from pathlib import Path
import hashlib,importlib.util,json,re,sys
sys.dont_write_bytecode=True
base=Path(__file__).resolve().parents[2];qual=base/'qualification';source=base/'work/polyphase-float'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def pin(p):return {'path':str(p.relative_to(base)),'sha256':sha(p)}
snapshot=qual/'SOURCE_SNAPSHOT_FINAL.json';expected=load(snapshot)
spec=importlib.util.spec_from_file_location('q',source/'tools/qualify_release.py');q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
matrix_path=next((qual/'final_matrix_retry').glob('qualification_*/qualification.json'));matrix=load(matrix_path)
fuzz_path=next((qual/'final_fuzz_retry').glob('qualification_*/qualification.json'));fuzz=load(fuzz_path)
supp_path=qual/'final_supplemental_retry/supplemental.json';supp=load(supp_path)
recovery_path=qual/'gcc_execute_mode_recovery/receipt.json';recovery=load(recovery_path)
manual_path=qual/'MANUAL_VALIDATION_FINAL.json';manual=load(manual_path)
consumers_path=qual/'manual_consumers_final_retry/receipt.json';consumers=load(consumers_path)
make_path=qual/'final_make/MAKE_FINAL.json';make=load(make_path)
corpus_path=qual/'FUZZ_CORPUS_ARCHIVE.json';corpus=load(corpus_path)
oracle_path=qual/'numerical/NUMERICAL_MANIFEST.json';oracle=load(oracle_path)
findings=[]
def require(test,message):
 if not test:findings.append(message)
require(q.snapshot(source)==expected,'Final source differs from canonical freeze')
for name,r in [('matrix',matrix),('fuzz',fuzz)]:
 require(r.get('source_snapshot_sha256')==sha(snapshot),name+' source snapshot differs')
 require(r.get('source_unchanged') is True,name+' source changed')
require(supp.get('source_snapshot')==expected and supp.get('source_unchanged') is True,'Supplemental source identity differs')
for name in ['clang-serial','gcc-openmp','asan']:
 require(matrix['scopes'][name]['status']=='PASS',name+' did not pass')
gcc=matrix['scopes']['gcc-serial'];gcc_ctest=gcc['steps'][-1]
require(gcc['status']=='FAIL' and gcc_ctest['test_counts']=={'failed':1,'passed':87,'total':88},'Unexpected original GCC failure pattern')
text=(matrix_path.parent/gcc_ctest['log']).read_text();require('60 - exhaustive_small (BAD_COMMAND)' in text and '[permission denied]' in text,'Original GCC failure was not recorded executable permission error')
require(recovery['status']=='PASS_RECOVERED_UNEXECUTED_TEST' and recovery['exit_code']==0,'Targeted GCC recovery failed')
require(recovery['sha256_before']==recovery['sha256_after_mode_repair']==recovery['sha256_after_test'],'GCC executable bytes changed during mode recovery')
require(recovery['source_snapshot_sha256']==sha(snapshot),'Recovery has different source identity')
require(fuzz['scopes']['fuzz']['status']=='PASS','Fuzz campaigns did not both complete')
for step in fuzz['scopes']['fuzz']['steps']:
 if step['name'] in ['text','fpif']:
  require(step['exit_code']==0 and step['elapsed_seconds']>=599,'Fuzz target did not finish recorded bounded campaign '+step['name'])
require(supp['status']=='PASS','Supplemental checks failed')
require(consumers['status']=='PASS','Literal manual installed consumers failed')
require(manual['status']=='PASS','Final manual validation failed')
require(make.get('passed') is True and make['source_snapshot_sha256']==sha(snapshot),'Final Make qualification failed or has different source identity')
require(oracle['run']['status']=='completed' and oracle['run']['exit_status']==0,'Finite oracle run did not complete')
require(corpus['archive_contents_verified'] is True,'Fuzz corpus archive not verified')
final_run=fuzz_path.parent
artifacts=[str(p.relative_to(base)) for p in (final_run/'artifacts').rglob('*') if p.is_file()]
require(not artifacts,'Fuzzer generated diagnostic artifacts: '+repr(artifacts))
counts={name:matrix['scopes'][name]['steps'][-1].get('test_counts') for name in ['gcc-serial','clang-serial','gcc-openmp','asan']}
r={'schema':'polyphase-float.final-qualification-summary/1','status':'PASS_WITH_RECORDED_EXECUTION_RECOVERY' if not findings else 'FAIL','frozen_source_snapshot':pin(snapshot),'source_files':len(expected),'source_unchanged':q.snapshot(source)==expected,'scope':'Bounded local Linux x86_64 source/archive, compiler, installed-consumption, contract, sanitizer, fuzz, manual and numerical checks; no stable1.0 promotion or outside-environment reproduction.','original_matrix_runner_status':matrix['status'],'original_matrix_required_matrix_complete':matrix['required_matrix_complete'],'original_suite_counts':counts,'gcc_execution_recovery':{'original':'87/88 tests passed; exhaustive_small could not launch because generated ELF mode was0644.','resolution':'Changed only executable permission0644->0755; identical executable SHA256; missing test then passed1/1.','receipt':pin(recovery_path)},'required_compiler_cases_executed_and_passed_after_documented_recovery':not findings,'receipts':{name:pin(p) for name,p in [('matrix',matrix_path),('fuzz',fuzz_path),('supplemental',supp_path),('manual',manual_path),('literal_manual_consumers',consumers_path),('make',make_path),('fuzz_corpus_archive',corpus_path),('finite_oracle',oracle_path)]},'fuzz_diagnostic_artifacts':artifacts,'findings':findings,'limitations':['Original failed/interrupted runs and diagnostics remain unchanged, with distinct receipts for recovery.','LeakSanitizer was explicitly disabled for ASan/UBSan/fuzz.','TSan checks exercise the focused thread-safety test, not all schedules.','Numerical checks are finite; complete proof/dependency mapping and complete cap-boundary coverage remain open.','Sustained fuzz execution history, full independent numerical/claim review, and two qualifying outside-environment correctness reproductions remain open for1.0.','Hosted GitHub checks are separately reported; local qualification does not imply hosted CI passed.'],'completed_utc':datetime.now(timezone.utc).isoformat()}
(qual/'FINAL_QUALIFICATION_SUMMARY.json').write_text(json.dumps(r,indent=2,sort_keys=True)+'\n');print(json.dumps({'status':r['status'],'counts':counts,'findings':findings},indent=2));raise SystemExit(bool(findings))
