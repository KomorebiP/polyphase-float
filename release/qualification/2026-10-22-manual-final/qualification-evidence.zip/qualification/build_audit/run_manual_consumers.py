#!/usr/bin/env python3
"""Execute the final manual's literal CMake consumers against a fresh installed core."""
from datetime import datetime, timezone
import argparse, hashlib, importlib.util, json, os
from pathlib import Path
import re, shlex, subprocess, sys, time
sys.dont_write_bytecode=True
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--prefix',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--snapshot',type=Path,required=True);a=p.parse_args()
source=a.source.resolve();prefix=a.prefix.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=False);(out/'logs').mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
s=importlib.util.spec_from_file_location('q',source/'tools/qualify_release.py');q=importlib.util.module_from_spec(s);s.loader.exec_module(q)
frozen=json.loads(a.snapshot.read_text())
if q.snapshot(source)!=frozen:raise RuntimeError('Source does not match freeze')
r={'status':'RUNNING','started_utc':datetime.now(timezone.utc).isoformat(),'snapshot_sha256':sha(a.snapshot),'steps':[],'fixtures':[],'installed_files_before':{str(p.relative_to(prefix)):sha(p) for p in sorted(prefix.rglob('*')) if p.is_file()}}
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','LC_ALL':'C','PATH':'/workspace/scratch/42e078a3c9ea/polyphase_release/qualification/dependencies/bin:'+os.environ['PATH']}
def save():(out/'receipt.json').write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
def run(name,cmd,expected=None):
 start=time.monotonic();p=subprocess.run(cmd,cwd=out,env=env,capture_output=True,text=True,timeout=180)
 stdout=out/'logs'/(name+'.stdout');stderr=out/'logs'/(name+'.stderr');stdout.write_text(p.stdout);stderr.write_text(p.stderr)
 r['steps'].append({'name':name,'command':cmd,'exit_code':p.returncode,'seconds':round(time.monotonic()-start,3),'stdout_sha256':sha(stdout),'stderr_sha256':sha(stderr)})
 save()
 if p.returncode or (expected is not None and p.stdout!=expected):raise RuntimeError(name+' failed or output mismatch')
 return p.stdout
save()
try:
 for chapter,target in [('02_build_install.md','my_calculation'),('14_integration_performance.md','polyphase_application')]:
  fixture=out/target;fixture.mkdir();path=source/'docs/manual/chapters'/chapter;text=path.read_text();block=re.search(r'^```cmake\n(.*?)^```',text,re.M|re.S).group(1)
  (fixture/'CMakeLists.txt').write_text(block);(fixture/'main.c').write_bytes((source/'examples/manual/intro_first.c').read_bytes())
  r['fixtures'].append({'chapter':str(path.relative_to(source)),'chapter_sha256':sha(path),'literal_cmake_sha256':sha(fixture/'CMakeLists.txt'),'application_sha256':sha(fixture/'main.c')})
  run(target+'_configure',['cmake','-S',str(fixture),'-B',str(fixture/'build'),'-DCMAKE_PREFIX_PATH='+str(prefix)])
  run(target+'_build',['cmake','--build',str(fixture/'build'),'-j2'])
  run(target+'_execute',[str(fixture/'build'/target)],expected='2 * 3 = 6.00000e0\n')
 pc=next(prefix.rglob('polyphase-float.pc'));env['PKG_CONFIG_PATH']=str(pc.parent);env['LD_LIBRARY_PATH']=str(pc.parent.parent)
 flags=run('pkg_config_flags',['pkg-config','--cflags','--libs','polyphase-float'])
 run('pkg_compile',['cc','-std=c11',str(out/'my_calculation/main.c'),'-o',str(out/'pkg_app'),*shlex.split(flags)])
 run('pkg_execute',[str(out/'pkg_app')],expected='2 * 3 = 6.00000e0\n')
 r['installed_files_after']={str(p.relative_to(prefix)):sha(p) for p in sorted(prefix.rglob('*')) if p.is_file()}
 if r['installed_files_before']!=r['installed_files_after']:raise RuntimeError('Installed files changed')
 r['changed_source_paths']=sorted(k for k in frozen.keys()|q.snapshot(source).keys() if frozen.get(k)!=q.snapshot(source).get(k))
 if r['changed_source_paths']:raise RuntimeError('Frozen source changed')
 r['status']='PASS'
except Exception as error:r.update(status='FAIL',error=str(error))
r['completed_utc']=datetime.now(timezone.utc).isoformat();save();print(json.dumps({'status':r['status'],'receipt':str(out/'receipt.json'),'error':r.get('error')},indent=2));raise SystemExit(r['status']!='PASS')
