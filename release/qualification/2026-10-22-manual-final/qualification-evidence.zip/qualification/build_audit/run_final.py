#!/usr/bin/env python3
"""Coordinate bounded final frozen-source qualification outside the source tree."""
from datetime import datetime, timezone
import hashlib, importlib.util, json, os
from pathlib import Path
import subprocess, sys, time
sys.dont_write_bytecode = True
base = Path(__file__).resolve().parents[2]
source = base/'work/polyphase-float'
plan = json.loads((base/'qualification/build_audit/RUN_PLAN.json').read_text())
snapshot_file = base/'qualification/SOURCE_SNAPSHOT_FINAL.json'
if not snapshot_file.is_file(): raise RuntimeError('No final snapshot; root must freeze first')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('q',source/'tools/qualify_release.py');q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
frozen=json.loads(snapshot_file.read_text())
if q.snapshot(source)!=frozen: raise RuntimeError('Frozen source differs from final snapshot')
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PATH':plan['environment']['PATH_prefix']+':'+os.environ['PATH']}
logs=base/'qualification/build_audit'
record={'status':'RUNNING','started_utc':datetime.now(timezone.utc).isoformat(),'source_snapshot_sha256':sha(snapshot_file),'source_snapshot_files':len(frozen),'processes':{}}
def save(): (logs/'FINAL_PROCESS_RECEIPT.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
processes={};streams={}
def start(name):
 command=plan['commands'][name]
 log=logs/(name+'_driver.log'); stream=log.open('wb')
 process=subprocess.Popen(command,cwd=base,env=env,stdout=stream,stderr=subprocess.STDOUT)
 processes[name]=process;streams[name]=stream
 record['processes'][name]={'command':command,'pid':process.pid,'started_utc':datetime.now(timezone.utc).isoformat(),'log':str(log)}
 save();print('STARTED '+name+' PID '+str(process.pid),flush=True)
for name in ('fuzz','matrix','supplemental'): start(name)
gate=base/'qualification/build_audit/SUPPLEMENTAL_BUILD_READY'
gate_written=False
while any(p.poll() is None for p in processes.values()):
 asan_ctest=list((base/'qualification/final_matrix_retry').glob('qualification_*/logs/asan/ctest.log'))
 if not gate_written and (asan_ctest or processes['matrix'].poll() is not None):
  gate.write_text(datetime.now(timezone.utc).isoformat()+'\n');gate_written=True
  print('SUPPLEMENTAL_BUILD_READY; ordinary matrix has no remaining compilation',flush=True)
 for name,p in processes.items():
  r=record['processes'][name]
  if p.poll() is not None and 'exit_code' not in r:
   streams[name].close();r.update(exit_code=p.returncode,completed_utc=datetime.now(timezone.utc).isoformat(),log_sha256=sha(Path(r['log'])));save();print('FINISHED '+name+' exit '+str(p.returncode),flush=True)
 time.sleep(1)
for name,p in processes.items():
 r=record['processes'][name]
 if 'exit_code' not in r:
  streams[name].close();r.update(exit_code=p.returncode,completed_utc=datetime.now(timezone.utc).isoformat(),log_sha256=sha(Path(r['log'])))
after=q.snapshot(source)
record['changed_source_paths']=sorted(k for k in frozen.keys()|after.keys() if frozen.get(k)!=after.get(k))
record['source_unchanged']=not record['changed_source_paths']
record['status']='PASS' if record['source_unchanged'] and all(r['exit_code']==0 for r in record['processes'].values()) else 'FAIL'
record['completed_utc']=datetime.now(timezone.utc).isoformat();save();print(json.dumps(record,indent=2),flush=True)
raise SystemExit(record['status']!='PASS')
