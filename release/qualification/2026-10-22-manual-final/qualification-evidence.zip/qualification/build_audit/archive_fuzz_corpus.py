#!/usr/bin/env python3
"""Preserve immutable seeds and every generated corpus/artifact from both attempts."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile
base=Path(__file__).resolve().parents[2]
qual=base/'qualification';output=qual/'fuzz-corpus.zip';files={};attempts=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for label,parent,status in [('before-claim-repair',qual/'final_fuzz','INTERRUPTED_SUPERSEDED'),('final',qual/'final_fuzz_retry','OBSERVE_RECEIPT')]:
 for run in sorted(parent.glob('qualification_*')):
  receipt=run/'qualification.json'
  entry={'label':label,'run':str(run.relative_to(base)),'status':status,'receipt_sha256':sha(receipt) if receipt.exists() else None}
  if receipt.exists():
   r=json.loads(receipt.read_text());entry.update(status=r['status'],fuzz_scope_status=r['scopes']['fuzz']['status'],source_snapshot_sha256=r['source_snapshot_sha256'],source_unchanged=r['source_unchanged'])
  attempts.append(entry)
  for name in ['corpus','artifacts']:
   for path in sorted((run/name).rglob('*')):
    if path.is_file():files[label+'/'+str(path.relative_to(run))]=path
for path in sorted((base/'work/polyphase-float/fuzz/corpus').rglob('*')):
 if path.is_file():files['immutable-seeds/'+str(path.relative_to(base/'work/polyphase-float/fuzz/corpus'))]=path
manifest={'schema':'polyphase-float.fuzz-corpus-archive/1','meaning':'Every seed, generated corpus input and diagnostic artifact is preserved; superseded interrupted attempts are explicitly labeled and are not completed campaign evidence.','attempts':attempts,'files':{name:{'sha256':sha(path),'bytes':path.stat().st_size} for name,path in files.items()}}
with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,path in sorted(files.items()):
  info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.external_attr=0o100644<<16;info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,path.read_bytes())
 info=zipfile.ZipInfo('MANIFEST.json',(1980,1,1,0,0,0));info.external_attr=0o100644<<16;info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode())
with zipfile.ZipFile(output) as z:
 if z.testzip() is not None:raise RuntimeError('ZIPCRCfailure')
 if sorted(z.namelist())!=sorted([*files,'MANIFEST.json']):raise RuntimeError('ZIPmembermismatch')
 for name,path in files.items():
  if hashlib.sha256(z.read(name)).hexdigest()!=sha(path):raise RuntimeError('ZIPbytecontentmismatch '+name)
envelope={**manifest,'zip':str(output.relative_to(base)),'zip_sha256':sha(output),'zip_bytes':output.stat().st_size,'members':len(files)+1,'archive_contents_verified':True,'created_utc':datetime.now(timezone.utc).isoformat()}
(qual/'FUZZ_CORPUS_ARCHIVE.json').write_text(json.dumps(envelope,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:envelope[k] for k in ['zip','zip_sha256','zip_bytes','members']},indent=2))
