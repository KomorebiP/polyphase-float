const char *ppf_print_rnd_mode(ppf_rnd_t rnd);
