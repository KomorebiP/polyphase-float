int ppf_root(
    ppf_t *rop,
    const ppf_t *a,
    unsigned long degree,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
