int ppf_nan_p(const ppf_t *x);
