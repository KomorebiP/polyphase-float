int ppf_setsign(
    ppf_t *rop,
    const ppf_t *op,
    int signbit,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
