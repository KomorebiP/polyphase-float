int ppf_pow_z(
    ppf_t *rop,
    const ppf_t *base,
    mpz_srcptr exponent,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
