int ppf_log_ui(
    ppf_t *rop,
    unsigned long op,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
