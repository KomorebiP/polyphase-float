ppf_product_algorithm_t ppf_plan_product_algorithm(
    const ppf_t *a,
    const ppf_t *b,
    int square,
    unsigned long workers
);
