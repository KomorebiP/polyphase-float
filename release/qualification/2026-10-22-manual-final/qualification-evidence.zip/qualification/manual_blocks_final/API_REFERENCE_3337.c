ppf_exp_t ppf_custom_get_exp(const ppf_t *x);
