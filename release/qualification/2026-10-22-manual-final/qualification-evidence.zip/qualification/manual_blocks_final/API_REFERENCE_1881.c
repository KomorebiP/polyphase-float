int ppf_init_set_z(
    ppf_t *rop,
    mpz_srcptr value,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
