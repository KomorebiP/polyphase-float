int ppf_pow_uj(
    ppf_t *rop,
    const ppf_t *base,
    uintmax_t exponent,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
