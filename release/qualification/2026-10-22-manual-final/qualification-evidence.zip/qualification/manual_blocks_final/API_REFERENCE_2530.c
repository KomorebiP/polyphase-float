int ppf_cmp_f(const ppf_t *op, mpf_srcptr value, ppf_context_t *ctx);
