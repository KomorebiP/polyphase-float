ppf_exp_t ppf_get_emax_max(void);
