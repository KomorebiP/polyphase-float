ppf_flags_t ppf_flags_test(ppf_flags_t mask);
