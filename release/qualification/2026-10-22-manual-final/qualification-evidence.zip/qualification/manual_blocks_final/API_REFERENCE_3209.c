void ppf_nextabove(ppf_t *x, ppf_context_t *ctx);
