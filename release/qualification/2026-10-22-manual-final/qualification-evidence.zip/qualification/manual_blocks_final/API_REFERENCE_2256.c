int ppf_fits_sshort_p(const ppf_t *op, ppf_rnd_t rnd);
