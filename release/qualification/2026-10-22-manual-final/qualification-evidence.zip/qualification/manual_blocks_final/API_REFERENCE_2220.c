int ppf_fits_intmax_p(const ppf_t *op, ppf_rnd_t rnd);
