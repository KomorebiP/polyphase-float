void ppf_custom_init(void *significand, ppf_prec_t precision);
