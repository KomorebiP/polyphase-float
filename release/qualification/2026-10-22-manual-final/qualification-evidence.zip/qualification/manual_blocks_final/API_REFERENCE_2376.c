size_t ppf_out_str(
    FILE *stream,
    int base,
    size_t digits,
    const ppf_t *op,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
