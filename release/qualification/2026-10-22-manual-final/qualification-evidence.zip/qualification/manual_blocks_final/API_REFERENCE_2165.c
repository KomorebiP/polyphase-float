uintmax_t ppf_get_uj(const ppf_t *op, ppf_rnd_t rnd, ppf_context_t *ctx);
