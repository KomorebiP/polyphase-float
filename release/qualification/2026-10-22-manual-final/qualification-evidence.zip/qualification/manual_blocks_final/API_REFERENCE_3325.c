const char *ppf_buildopt_tune_case(void);
