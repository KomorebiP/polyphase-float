void ppf_context_flags_set(ppf_context_t *ctx, ppf_flags_t mask);
