int ppf_erandom(
    ppf_t *rop,
    gmp_randstate_t state,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
