int ppf_check_range(
    ppf_t *x,
    int ternary,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
