int ppf_can_round(
    const ppf_t *approximation,
    ppf_exp_t error_bits,
    ppf_rnd_t source_rounding,
    ppf_rnd_t target_rounding,
    ppf_prec_t target_precision
);
