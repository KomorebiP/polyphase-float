int ppf_set_z_2exp(
    ppf_t *rop,
    mpz_srcptr value,
    ppf_exp_t exponent,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
