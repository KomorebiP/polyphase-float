int ppf_round_nearest_away_finish(
    ppf_t *rop,
    const ppf_t *extended_result,
    int extended_ternary,
    ppf_context_t *ctx
);
