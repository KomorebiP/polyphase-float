unsigned long ppf_divisor_plan_applications(
    const ppf_divisor_plan_t *plan
);
