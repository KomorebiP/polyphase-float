ppf_flags_t ppf_flags_save(void);
