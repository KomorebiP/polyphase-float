int ppf_init_set_uj(
    ppf_t *rop,
    uintmax_t value,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
