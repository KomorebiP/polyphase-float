int ppf_set_emin(ppf_exp_t exponent);
