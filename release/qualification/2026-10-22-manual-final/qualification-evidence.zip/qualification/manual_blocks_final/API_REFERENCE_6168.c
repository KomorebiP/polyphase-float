int ppf_atan2(
    ppf_t *rop,
    const ppf_t *y,
    const ppf_t *x,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
