void ppf_clear_nanflag(void);
