int ppf_set_default_rounding_mode(ppf_rnd_t rnd);
