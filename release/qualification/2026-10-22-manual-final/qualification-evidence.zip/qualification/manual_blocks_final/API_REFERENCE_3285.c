int ppf_buildopt_float128_p(void);
