int ppf_rec_sqrt_algorithm_threads(
    ppf_t *rop,
    const ppf_t *a,
    ppf_rnd_t rnd,
    unsigned long workers,
    ppf_product_algorithm_t algorithm,
    ppf_context_t *ctx
);
