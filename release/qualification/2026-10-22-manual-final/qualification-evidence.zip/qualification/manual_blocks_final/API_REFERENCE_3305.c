int ppf_buildopt_sharedcache_p(void);
