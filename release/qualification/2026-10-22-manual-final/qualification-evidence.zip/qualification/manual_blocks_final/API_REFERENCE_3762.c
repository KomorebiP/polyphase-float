int ppf_get_abi_info(ppf_abi_info_t *info, size_t info_size);
