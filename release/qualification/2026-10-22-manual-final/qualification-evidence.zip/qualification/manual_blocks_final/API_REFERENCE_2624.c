int ppf_cmp_z(const ppf_t *op, mpz_srcptr value, ppf_context_t *ctx);
