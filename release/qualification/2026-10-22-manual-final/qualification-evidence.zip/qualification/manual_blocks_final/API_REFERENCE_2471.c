int ppf_vsnprintf(
    char *buffer,
    size_t size,
    const char *format,
    va_list ap
);
