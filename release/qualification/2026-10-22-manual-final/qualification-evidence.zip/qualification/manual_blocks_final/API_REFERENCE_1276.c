int ppf_set_decimal128(
    ppf_t *rop,
    ppf_decimal128_t value,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
