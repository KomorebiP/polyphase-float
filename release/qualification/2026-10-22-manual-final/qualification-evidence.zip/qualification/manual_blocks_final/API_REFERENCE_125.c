void ppf_context_flags_clear(ppf_context_t *ctx, ppf_flags_t mask);
