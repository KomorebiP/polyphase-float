int ppf_fits_slong_p(const ppf_t *op, ppf_rnd_t rnd);
