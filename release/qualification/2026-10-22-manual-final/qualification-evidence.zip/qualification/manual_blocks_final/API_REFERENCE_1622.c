int ppf_strtofr(
    ppf_t *rop,
    const char *text,
    char **endptr,
    int base,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
