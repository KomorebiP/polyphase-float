void ppf_free_str(char *text);
