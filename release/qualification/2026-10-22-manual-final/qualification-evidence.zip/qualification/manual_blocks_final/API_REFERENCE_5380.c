int ppf_compound_si(
    ppf_t *rop,
    const ppf_t *op,
    long exponent,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
