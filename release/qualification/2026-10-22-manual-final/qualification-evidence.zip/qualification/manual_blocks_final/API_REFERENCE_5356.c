int ppf_sum(
    ppf_t *rop,
    const ppf_t *const values[],
    size_t length,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
