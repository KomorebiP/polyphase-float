int ppf_context_clone(ppf_context_t *dst, const ppf_context_t *src);
