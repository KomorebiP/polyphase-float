int ppf_allocflag_p(void);
