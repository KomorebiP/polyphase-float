const char *ppf_abi_tag(void);
