const char *ppf_product_profile_sha256(void);
