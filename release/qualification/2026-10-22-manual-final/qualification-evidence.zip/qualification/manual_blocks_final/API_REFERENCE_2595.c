int ppf_cmp_ui(const ppf_t *op, unsigned long value, ppf_context_t *ctx);
