uint32_t ppf_abi_revision(void);
