ppf_allocator_t ppf_default_allocator(void);
