int ppf_rootn_si(
    ppf_t *rop,
    const ppf_t *a,
    long degree,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
