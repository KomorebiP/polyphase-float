int ppf_d_sub(
    ppf_t *rop,
    double value,
    const ppf_t *op,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
