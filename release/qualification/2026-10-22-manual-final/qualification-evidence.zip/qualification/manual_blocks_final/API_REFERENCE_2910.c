int ppf_remainder(
    ppf_t *rop,
    const ppf_t *x,
    const ppf_t *y,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
