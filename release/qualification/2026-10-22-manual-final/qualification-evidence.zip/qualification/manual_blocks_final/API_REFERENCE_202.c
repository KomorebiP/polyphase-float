int ppf_context_set_default_precision(
    ppf_context_t *ctx,
    ppf_prec_t precision
);
