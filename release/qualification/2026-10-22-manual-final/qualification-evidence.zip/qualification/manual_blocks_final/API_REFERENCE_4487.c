int ppf_sub_si(
    ppf_t *rop,
    const ppf_t *op,
    long value,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
