int ppf_mul(
    ppf_t *rop,
    const ppf_t *a,
    const ppf_t *b,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
