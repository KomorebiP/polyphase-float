void ppf_set_zero(ppf_t *x, int sign);
