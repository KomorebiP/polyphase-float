void ppf_reldiff(
    ppf_t *rop,
    const ppf_t *op1,
    const ppf_t *op2,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
