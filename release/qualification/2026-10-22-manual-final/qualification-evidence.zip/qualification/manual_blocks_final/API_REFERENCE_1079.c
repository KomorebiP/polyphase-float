int ppf_number_p(const ppf_t *x);
