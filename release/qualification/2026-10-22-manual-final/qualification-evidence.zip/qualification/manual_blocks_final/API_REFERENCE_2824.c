int ppf_fmodquo(
    ppf_t *rop,
    long *quotient_bits,
    const ppf_t *x,
    const ppf_t *y,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
