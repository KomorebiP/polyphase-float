int ppf_init_set_sj(
    ppf_t *rop,
    intmax_t value,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
