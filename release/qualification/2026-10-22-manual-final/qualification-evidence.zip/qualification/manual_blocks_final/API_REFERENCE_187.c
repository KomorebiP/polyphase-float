int ppf_context_init_custom(
    ppf_context_t *ctx,
    const ppf_allocator_t *allocator
);
