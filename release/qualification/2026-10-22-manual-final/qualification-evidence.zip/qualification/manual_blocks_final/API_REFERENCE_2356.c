size_t ppf_inp_str(
    ppf_t *rop,
    FILE *stream,
    int base,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
