int ppf_cmp_ld(const ppf_t *op, long double value, ppf_context_t *ctx);
