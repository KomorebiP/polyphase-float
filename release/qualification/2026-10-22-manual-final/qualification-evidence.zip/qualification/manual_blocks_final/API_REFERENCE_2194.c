ppf_exp_t ppf_get_z_2exp(mpz_ptr value, const ppf_t *op);
