ppf_exp_t ppf_get_exp(const ppf_t *x, ppf_context_t *ctx);
