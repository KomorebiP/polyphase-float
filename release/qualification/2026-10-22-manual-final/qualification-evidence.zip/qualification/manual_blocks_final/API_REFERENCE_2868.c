int ppf_integer_p(const ppf_t *op);
