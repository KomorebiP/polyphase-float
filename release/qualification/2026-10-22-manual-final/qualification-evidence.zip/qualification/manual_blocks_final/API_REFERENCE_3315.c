int ppf_buildopt_tls_p(void);
