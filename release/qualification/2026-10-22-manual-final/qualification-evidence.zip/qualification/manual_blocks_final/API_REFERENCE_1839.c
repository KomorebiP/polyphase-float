int ppf_init_set_ui(
    ppf_t *rop,
    unsigned long value,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
