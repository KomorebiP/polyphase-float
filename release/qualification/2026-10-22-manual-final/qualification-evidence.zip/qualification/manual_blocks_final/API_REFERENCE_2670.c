int ppf_greaterequal_p(const ppf_t *a, const ppf_t *b);
