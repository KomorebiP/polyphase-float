ppf_float128_t ppf_get_float128(
    const ppf_t *op,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
