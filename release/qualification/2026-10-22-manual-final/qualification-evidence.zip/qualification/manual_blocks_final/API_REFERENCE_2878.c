ppf_prec_t ppf_min_prec(const ppf_t *op);
