int ppf_init_set_q(
    ppf_t *rop,
    mpq_srcptr value,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
