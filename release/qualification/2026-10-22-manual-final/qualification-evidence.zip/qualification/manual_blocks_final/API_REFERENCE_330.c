void ppf_clear_divby0(void);
