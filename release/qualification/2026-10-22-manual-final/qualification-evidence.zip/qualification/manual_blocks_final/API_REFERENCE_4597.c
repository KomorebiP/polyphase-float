int ppf_z_sub(
    ppf_t *rop,
    mpz_srcptr value,
    const ppf_t *op,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
