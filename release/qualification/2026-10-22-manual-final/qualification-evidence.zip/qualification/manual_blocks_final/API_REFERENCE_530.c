ppf_exp_t ppf_get_emin(void);
