int ppf_regular_p(const ppf_t *x);
