void ppf_flags_clear(ppf_flags_t mask);
