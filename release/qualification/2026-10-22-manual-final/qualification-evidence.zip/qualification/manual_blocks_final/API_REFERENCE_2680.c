int ppf_less_p(const ppf_t *a, const ppf_t *b);
