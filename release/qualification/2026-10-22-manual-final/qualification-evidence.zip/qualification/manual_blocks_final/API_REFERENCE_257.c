ppf_context_t *ppf_default_context(void);
