int ppf_fpif_import(ppf_t *op, FILE *stream, ppf_context_t *ctx);
