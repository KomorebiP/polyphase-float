int ppf_custom_get_kind(const ppf_t *x);
