int ppf_mul_2ui(
    ppf_t *rop,
    const ppf_t *a,
    unsigned long shift,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
