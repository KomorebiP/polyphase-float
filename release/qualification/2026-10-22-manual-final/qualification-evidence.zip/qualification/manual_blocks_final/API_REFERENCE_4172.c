int ppf_mul_si(
    ppf_t *rop,
    const ppf_t *op,
    long value,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
