int ppf_eq(const ppf_t *op1, const ppf_t *op2, unsigned long bits);
