ppf_prec_t ppf_divisor_plan_precision( const ppf_divisor_plan_t *plan);
