int ppf_vfprintf(FILE *stream, const char *format, va_list ap);
