int ppf_fits_ulong_p(const ppf_t *op, ppf_rnd_t rnd);
