int ppf_get_f(
    mpf_ptr value,
    const ppf_t *op,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
