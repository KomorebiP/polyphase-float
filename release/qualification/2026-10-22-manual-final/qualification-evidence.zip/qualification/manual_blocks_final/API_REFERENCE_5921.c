int ppf_ui_pow_ui(
    ppf_t *rop,
    unsigned long base,
    unsigned long exponent,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
