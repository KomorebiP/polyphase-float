int ppf_fma(
    ppf_t *rop,
    const ppf_t *a,
    const ppf_t *b,
    const ppf_t *c,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
