int ppf_signbit(const ppf_t *x);
