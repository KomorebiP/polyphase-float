int ppf_inf_p(const ppf_t *x);
