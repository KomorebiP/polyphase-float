int ppf_context_set_range(
    ppf_context_t *ctx,
    ppf_exp_t emin,
    ppf_exp_t emax
);
