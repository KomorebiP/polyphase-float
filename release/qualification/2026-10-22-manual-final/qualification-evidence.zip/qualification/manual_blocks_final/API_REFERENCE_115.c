ppf_flags_t ppf_context_flags(const ppf_context_t *ctx);
