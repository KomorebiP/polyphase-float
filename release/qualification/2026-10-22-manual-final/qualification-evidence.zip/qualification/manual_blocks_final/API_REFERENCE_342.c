void ppf_clear_erangeflag(void);
