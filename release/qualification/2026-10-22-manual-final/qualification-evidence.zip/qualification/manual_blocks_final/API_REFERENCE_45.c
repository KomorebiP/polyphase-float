ppf_arena_mark_t ppf_arena_mark(const ppf_context_t *ctx);
