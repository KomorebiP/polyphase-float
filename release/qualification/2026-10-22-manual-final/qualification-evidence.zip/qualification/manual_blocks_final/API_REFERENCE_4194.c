int ppf_mul_threads(
    ppf_t *rop,
    const ppf_t *a,
    const ppf_t *b,
    ppf_rnd_t rnd,
    unsigned long workers,
    ppf_context_t *ctx
);
