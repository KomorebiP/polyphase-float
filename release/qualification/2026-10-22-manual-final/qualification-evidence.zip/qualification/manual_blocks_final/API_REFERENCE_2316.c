int ppf_fpif_export(FILE *stream, const ppf_t *op);
