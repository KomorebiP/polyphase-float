int ppf_fits_sint_p(const ppf_t *op, ppf_rnd_t rnd);
