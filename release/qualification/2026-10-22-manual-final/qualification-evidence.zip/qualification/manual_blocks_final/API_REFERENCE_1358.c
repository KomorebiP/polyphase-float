int ppf_set_flt(ppf_t *rop, float value, ppf_rnd_t rnd, ppf_context_t *ctx);
