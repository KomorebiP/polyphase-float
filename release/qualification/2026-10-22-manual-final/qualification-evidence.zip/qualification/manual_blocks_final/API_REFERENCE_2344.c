int ppf_fprintf(FILE *stream, const char *format, ...);
