int ppf_atan2u(
    ppf_t *rop,
    const ppf_t *y,
    const ppf_t *x,
    unsigned long u,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
