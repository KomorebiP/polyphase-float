int ppf_mul_2exp(
    ppf_t *rop,
    const ppf_t *op,
    unsigned long exponent,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
