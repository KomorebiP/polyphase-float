unsigned long ppf_get_ui(
    const ppf_t *op,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
