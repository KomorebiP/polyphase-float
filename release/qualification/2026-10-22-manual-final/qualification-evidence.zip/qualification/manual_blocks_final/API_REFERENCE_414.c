int ppf_divby0_p(void);
