int ppf_vasprintf(char **text, const char *format, va_list ap);
