void ppf_set_divby0(void);
