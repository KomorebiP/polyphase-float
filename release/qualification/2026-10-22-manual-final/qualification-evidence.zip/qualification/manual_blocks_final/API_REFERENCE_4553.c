int ppf_ui_div(
    ppf_t *rop,
    unsigned long value,
    const ppf_t *op,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
