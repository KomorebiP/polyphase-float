int ppf_fits_uint_p(const ppf_t *op, ppf_rnd_t rnd);
