int ppf_greater_p(const ppf_t *a, const ppf_t *b);
