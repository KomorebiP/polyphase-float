int ppf_si_div(
    ppf_t *rop,
    long value,
    const ppf_t *op,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
