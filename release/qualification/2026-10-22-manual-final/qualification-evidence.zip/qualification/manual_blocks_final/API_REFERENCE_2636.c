int ppf_cmpabs(const ppf_t *a, const ppf_t *b, ppf_context_t *ctx);
