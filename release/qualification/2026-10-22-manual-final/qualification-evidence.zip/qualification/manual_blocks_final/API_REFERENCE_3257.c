int ppf_set_exp(ppf_t *x, ppf_exp_t exponent, ppf_context_t *ctx);
