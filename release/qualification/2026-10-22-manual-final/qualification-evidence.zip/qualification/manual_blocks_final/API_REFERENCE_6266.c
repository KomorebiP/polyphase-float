int ppf_atanpi(
    ppf_t *rop,
    const ppf_t *op,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
