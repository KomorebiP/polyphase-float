int ppf_div_2si(
    ppf_t *rop,
    const ppf_t *a,
    long shift,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
