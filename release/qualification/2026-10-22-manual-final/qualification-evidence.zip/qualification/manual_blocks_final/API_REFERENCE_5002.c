int ppf_divisor_plan_create_ex(
    ppf_divisor_plan_t **out,
    const ppf_t *denominator,
    ppf_prec_t destination_precision,
    unsigned long expected_applications,
    ppf_context_t *ctx
);
