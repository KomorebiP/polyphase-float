void ppf_nextbelow(ppf_t *x, ppf_context_t *ctx);
