int ppf_set_si(ppf_t *rop, long value, ppf_rnd_t rnd, ppf_context_t *ctx);
