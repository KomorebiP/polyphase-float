int ppf_total_order_p(const ppf_t *a, const ppf_t *b);
