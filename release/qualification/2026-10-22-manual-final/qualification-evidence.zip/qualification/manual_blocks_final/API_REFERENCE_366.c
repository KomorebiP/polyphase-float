void ppf_clear_inexflag(void);
