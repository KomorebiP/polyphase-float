int ppf_set_str(
    ppf_t *rop,
    const char *text,
    int base,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
