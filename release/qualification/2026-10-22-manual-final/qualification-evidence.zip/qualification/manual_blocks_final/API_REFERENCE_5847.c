int ppf_pown(
    ppf_t *rop,
    const ppf_t *base,
    intmax_t exponent,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
