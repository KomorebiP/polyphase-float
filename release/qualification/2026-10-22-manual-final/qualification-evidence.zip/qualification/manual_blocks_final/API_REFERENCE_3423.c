void ppf_custom_move(ppf_t *x, void *new_position);
