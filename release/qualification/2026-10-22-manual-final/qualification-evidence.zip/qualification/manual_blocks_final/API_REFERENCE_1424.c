int ppf_set_si_2exp(
    ppf_t *rop,
    long value,
    ppf_exp_t exponent,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
