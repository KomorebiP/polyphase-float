float ppf_get_flt(const ppf_t *op, ppf_rnd_t rnd, ppf_context_t *ctx);
