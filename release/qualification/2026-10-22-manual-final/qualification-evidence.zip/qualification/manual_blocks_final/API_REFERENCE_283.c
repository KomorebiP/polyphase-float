void ppf_set_allocflag(void);
