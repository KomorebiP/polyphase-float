const char *ppf_product_profile_name(void);
