int ppf_sgn(const ppf_t *x, ppf_context_t *ctx);
