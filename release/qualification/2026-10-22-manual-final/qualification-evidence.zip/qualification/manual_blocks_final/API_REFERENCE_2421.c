int ppf_sprintf(char *buffer, const char *format, ...);
