int ppf_add_si(
    ppf_t *rop,
    const ppf_t *op,
    long value,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
