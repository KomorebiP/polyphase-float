void ppf_context_flags_restore(
    ppf_context_t *ctx,
    ppf_flags_t flags,
    ppf_flags_t mask
);
