int ppf_dot_threads(
    ppf_t *rop,
    const ppf_t *const a[],
    const ppf_t *const b[],
    size_t length,
    ppf_rnd_t rnd,
    unsigned long workers,
    ppf_context_t *ctx
);
