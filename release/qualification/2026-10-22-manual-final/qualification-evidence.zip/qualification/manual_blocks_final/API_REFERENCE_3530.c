const char *ppf_get_patches(void);
