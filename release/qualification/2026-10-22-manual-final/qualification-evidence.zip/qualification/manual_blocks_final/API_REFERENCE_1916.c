int ppf_frexp(
    ppf_exp_t *exponent,
    ppf_t *mantissa,
    const ppf_t *op,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
