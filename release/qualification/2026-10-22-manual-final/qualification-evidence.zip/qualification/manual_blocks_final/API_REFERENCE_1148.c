void ppf_set_inf(ppf_t *x, int sign);
