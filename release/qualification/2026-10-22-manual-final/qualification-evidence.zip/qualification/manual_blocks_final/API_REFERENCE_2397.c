int ppf_printf(const char *format, ...);
