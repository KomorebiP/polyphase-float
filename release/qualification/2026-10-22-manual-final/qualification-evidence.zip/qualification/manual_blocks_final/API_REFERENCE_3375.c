size_t ppf_custom_get_size(ppf_prec_t precision);
