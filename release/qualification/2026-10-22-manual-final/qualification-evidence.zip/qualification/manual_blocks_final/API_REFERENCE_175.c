int ppf_context_init(ppf_context_t *ctx);
