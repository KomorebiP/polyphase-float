size_t ppf_get_str_ndigits(int base, ppf_prec_t precision);
