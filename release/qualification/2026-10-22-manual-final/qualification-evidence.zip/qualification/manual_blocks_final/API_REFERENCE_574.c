int ppf_nanflag_p(void);
