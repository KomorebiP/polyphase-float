int ppf_cmp_q(const ppf_t *op, mpq_srcptr value, ppf_context_t *ctx);
