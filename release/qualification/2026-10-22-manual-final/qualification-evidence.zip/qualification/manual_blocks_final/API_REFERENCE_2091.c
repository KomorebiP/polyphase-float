long ppf_get_si(const ppf_t *op, ppf_rnd_t rnd, ppf_context_t *ctx);
