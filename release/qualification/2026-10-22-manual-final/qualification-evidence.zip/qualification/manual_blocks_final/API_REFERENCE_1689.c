int ppf_init_set_f(
    ppf_t *rop,
    mpf_srcptr value,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
