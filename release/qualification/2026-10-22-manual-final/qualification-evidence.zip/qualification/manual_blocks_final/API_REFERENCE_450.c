void ppf_flags_restore(ppf_flags_t flags, ppf_flags_t mask);
