int ppf_round(ppf_t *rop, const ppf_t *op, ppf_context_t *ctx);
