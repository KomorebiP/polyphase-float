int ppf_buildopt_decimal_p(void);
