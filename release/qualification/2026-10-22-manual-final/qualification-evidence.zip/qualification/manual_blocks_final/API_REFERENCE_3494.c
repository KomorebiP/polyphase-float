void ppf_free_cache(void);
