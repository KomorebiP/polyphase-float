void ppf_flags_set(ppf_flags_t mask);
