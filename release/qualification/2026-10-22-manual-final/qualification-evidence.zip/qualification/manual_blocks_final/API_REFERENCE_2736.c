int ppf_unordered_p(const ppf_t *a, const ppf_t *b);
