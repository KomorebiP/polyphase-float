int ppf_custom_init_set(
    ppf_t *x,
    int kind,
    ppf_exp_t exponent,
    ppf_prec_t precision,
    void *significand
);
