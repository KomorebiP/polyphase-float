int ppf_get_z(
    mpz_ptr value,
    const ppf_t *op,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
