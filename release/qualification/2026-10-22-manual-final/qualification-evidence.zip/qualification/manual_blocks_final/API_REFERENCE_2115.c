char *ppf_get_str(
    char *buffer,
    ppf_exp_t *exponent,
    int base,
    size_t digits,
    const ppf_t *op,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
