int ppf_set_sj_2exp(
    ppf_t *rop,
    intmax_t value,
    ppf_exp_t exponent,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
