int ppf_vprintf(const char *format, va_list ap);
