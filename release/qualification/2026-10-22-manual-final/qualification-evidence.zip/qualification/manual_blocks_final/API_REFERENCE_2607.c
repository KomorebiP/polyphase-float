int ppf_cmp_ui_2exp(
    const ppf_t *op,
    unsigned long value,
    ppf_exp_t exponent,
    ppf_context_t *ctx
);
