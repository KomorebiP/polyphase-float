int ppf_fmod_ui(
    ppf_t *rop,
    const ppf_t *x,
    unsigned long y,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
