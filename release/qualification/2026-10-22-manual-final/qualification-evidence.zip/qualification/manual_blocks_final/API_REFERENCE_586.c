int ppf_overflow_p(void);
