void ppf_default_context_cleanup(void);
