int ppf_pow_si(
    ppf_t *rop,
    const ppf_t *base,
    long exponent,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
