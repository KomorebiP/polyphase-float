int ppf_erangeflag_p(void);
