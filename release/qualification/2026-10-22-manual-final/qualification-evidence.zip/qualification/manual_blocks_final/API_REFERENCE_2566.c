int ppf_cmp_si(const ppf_t *op, long value, ppf_context_t *ctx);
