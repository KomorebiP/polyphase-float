int ppf_set_emax(ppf_exp_t exponent);
