int ppf_fits_ushort_p(const ppf_t *op, ppf_rnd_t rnd);
