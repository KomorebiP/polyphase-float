void ppf_free_cache2(ppf_free_cache_t way);
