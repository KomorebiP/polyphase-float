int ppf_set_d(ppf_t *rop, double value, ppf_rnd_t rnd, ppf_context_t *ctx);
