size_t ppf_abi_info_size(void);
