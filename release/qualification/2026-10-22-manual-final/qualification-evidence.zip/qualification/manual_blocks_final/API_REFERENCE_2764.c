int ppf_floor(ppf_t *rop, const ppf_t *op, ppf_context_t *ctx);
