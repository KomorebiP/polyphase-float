int ppf_add_q(
    ppf_t *rop,
    const ppf_t *op,
    mpq_srcptr value,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
