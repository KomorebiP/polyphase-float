int ppf_div_with_plan(
    ppf_t *rop,
    const ppf_t *numerator,
    const ppf_divisor_plan_t *plan,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
