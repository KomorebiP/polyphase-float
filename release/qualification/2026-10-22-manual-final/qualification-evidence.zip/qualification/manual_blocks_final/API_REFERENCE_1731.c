int ppf_init_set_ld(
    ppf_t *rop,
    long double value,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
