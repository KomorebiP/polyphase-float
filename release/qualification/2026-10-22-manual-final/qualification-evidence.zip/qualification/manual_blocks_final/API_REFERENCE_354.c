void ppf_clear_flags(void);
