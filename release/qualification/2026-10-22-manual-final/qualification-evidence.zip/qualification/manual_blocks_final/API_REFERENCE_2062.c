long double ppf_get_ld_2exp(
    long *exponent,
    const ppf_t *op,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
