int ppf_set_float128(
    ppf_t *rop,
    ppf_float128_t value,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
