int ppf_buildopt_gmpinternals_p(void);
