void ppf_divisor_plan_destroy(ppf_divisor_plan_t *plan);
