int ppf_set_decimal64(
    ppf_t *rop,
    ppf_decimal64_t value,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
