int ppf_grandom(
    ppf_t *rop1,
    ppf_t *rop2,
    gmp_randstate_t state,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
