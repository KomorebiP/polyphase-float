int ppf_sqr_threads(
    ppf_t *rop,
    const ppf_t *a,
    ppf_rnd_t rnd,
    unsigned long workers,
    ppf_context_t *ctx
);
