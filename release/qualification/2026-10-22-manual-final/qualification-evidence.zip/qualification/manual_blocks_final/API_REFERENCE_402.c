void ppf_clear_underflow(void);
