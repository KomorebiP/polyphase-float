void *ppf_custom_get_significand(const ppf_t *x);
