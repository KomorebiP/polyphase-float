int ppf_ui_pow(
    ppf_t *rop,
    unsigned long base,
    const ppf_t *exponent,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
