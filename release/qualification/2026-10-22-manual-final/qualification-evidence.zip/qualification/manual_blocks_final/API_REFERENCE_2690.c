int ppf_lessequal_p(const ppf_t *a, const ppf_t *b);
