int ppf_inexflag_p(void);
