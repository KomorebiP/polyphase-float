int ppf_pow_ui(
    ppf_t *rop,
    const ppf_t *base,
    unsigned long exponent,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
