int ppf_fmma(
    ppf_t *rop,
    const ppf_t *a,
    const ppf_t *b,
    const ppf_t *c,
    const ppf_t *d,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
