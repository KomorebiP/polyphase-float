int ppf_mul_ui(
    ppf_t *rop,
    const ppf_t *op,
    unsigned long value,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
