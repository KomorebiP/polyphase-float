void ppf_get_q(mpq_ptr value, const ppf_t *op, ppf_context_t *ctx);
