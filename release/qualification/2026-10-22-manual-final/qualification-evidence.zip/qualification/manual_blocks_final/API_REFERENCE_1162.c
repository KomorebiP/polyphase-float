void ppf_set_nan(ppf_t *x, int sign);
