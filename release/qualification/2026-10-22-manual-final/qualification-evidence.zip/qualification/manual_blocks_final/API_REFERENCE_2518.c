int ppf_cmp_d(const ppf_t *op, double value, ppf_context_t *ctx);
