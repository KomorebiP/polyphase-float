int ppf_vsprintf(char *buffer, const char *format, va_list ap);
