int ppf_atanu(
    ppf_t *rop,
    const ppf_t *op,
    unsigned long u,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
