int ppf_buildopt_thread_cleanup_p(void);
