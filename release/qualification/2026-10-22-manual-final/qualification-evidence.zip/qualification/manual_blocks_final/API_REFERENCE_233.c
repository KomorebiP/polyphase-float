int ppf_context_set_rounding(ppf_context_t *ctx, ppf_rnd_t rnd);
