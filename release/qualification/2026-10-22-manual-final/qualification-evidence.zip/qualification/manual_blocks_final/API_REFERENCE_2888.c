int ppf_modf(
    ppf_t *integer_part,
    ppf_t *fractional_part,
    const ppf_t *op,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
