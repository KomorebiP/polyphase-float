int ppf_powr(
    ppf_t *rop,
    const ppf_t *base,
    const ppf_t *exponent,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
