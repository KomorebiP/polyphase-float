int ppf_rec_sqrt(
    ppf_t *rop,
    const ppf_t *a,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
