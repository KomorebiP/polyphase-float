int ppf_fms_algorithm_threads(
    ppf_t *rop,
    const ppf_t *a,
    const ppf_t *b,
    const ppf_t *c,
    ppf_rnd_t rnd,
    unsigned long workers,
    ppf_product_algorithm_t algorithm,
    ppf_context_t *ctx
);
