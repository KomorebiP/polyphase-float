uint32_t ppf_abi_epoch(void);
