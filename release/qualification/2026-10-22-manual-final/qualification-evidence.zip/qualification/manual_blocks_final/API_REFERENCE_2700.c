int ppf_lessgreater_p(const ppf_t *a, const ppf_t *b);
