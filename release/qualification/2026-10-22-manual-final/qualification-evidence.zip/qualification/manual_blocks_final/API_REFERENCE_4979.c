int ppf_divisor_plan_create(
    ppf_divisor_plan_t **out,
    const ppf_t *denominator,
    ppf_prec_t destination_precision,
    ppf_context_t *ctx
);
