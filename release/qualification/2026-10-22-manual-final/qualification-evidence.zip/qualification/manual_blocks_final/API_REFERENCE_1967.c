ppf_decimal128_t ppf_get_decimal128(
    const ppf_t *op,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
