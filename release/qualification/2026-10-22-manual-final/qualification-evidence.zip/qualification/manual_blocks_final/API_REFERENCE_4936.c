int ppf_div_with_plan_many(
    ppf_t *outputs[],
    const ppf_t *const numerators[],
    size_t length,
    const ppf_divisor_plan_t *plan,
    ppf_rnd_t rnd,
    unsigned long workers,
    int ternaries[],
    ppf_context_t *ctx
);
