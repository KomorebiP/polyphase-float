ppf_rnd_t ppf_get_default_rounding_mode(void);
