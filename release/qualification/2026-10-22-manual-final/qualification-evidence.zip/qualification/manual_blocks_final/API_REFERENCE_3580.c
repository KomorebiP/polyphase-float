int ppf_mp_memory_cleanup(void);
