double ppf_get_d(const ppf_t *op, ppf_rnd_t rnd, ppf_context_t *ctx);
