const char *ppf_abi_contract_sha256(void);
