int ppf_urandomb(ppf_t *rop, gmp_randstate_t state);
