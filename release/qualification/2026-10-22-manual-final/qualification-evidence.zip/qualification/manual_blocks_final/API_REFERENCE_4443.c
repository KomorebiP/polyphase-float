int ppf_sub_d(
    ppf_t *rop,
    const ppf_t *op,
    double value,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
