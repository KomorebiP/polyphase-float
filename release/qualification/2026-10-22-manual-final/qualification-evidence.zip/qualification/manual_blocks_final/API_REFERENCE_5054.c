int ppf_dot(
    ppf_t *rop,
    const ppf_t *const a[],
    const ppf_t *const b[],
    size_t length,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
