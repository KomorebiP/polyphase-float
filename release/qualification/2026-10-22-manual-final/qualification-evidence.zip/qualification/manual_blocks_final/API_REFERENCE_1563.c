int ppf_set_uj_2exp(
    ppf_t *rop,
    uintmax_t value,
    ppf_exp_t exponent,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
