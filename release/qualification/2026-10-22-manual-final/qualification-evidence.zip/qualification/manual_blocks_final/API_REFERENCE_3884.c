int ppf_add_z(
    ppf_t *rop,
    const ppf_t *op,
    mpz_srcptr value,
    ppf_rnd_t rnd,
    ppf_context_t *ctx
);
