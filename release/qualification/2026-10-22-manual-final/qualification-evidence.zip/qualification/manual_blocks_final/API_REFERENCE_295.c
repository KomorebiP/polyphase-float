void ppf_thread_cleanup(void);
