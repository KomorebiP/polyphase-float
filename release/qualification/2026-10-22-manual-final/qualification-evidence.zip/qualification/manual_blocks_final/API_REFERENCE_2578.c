int ppf_cmp_si_2exp(
    const ppf_t *op,
    long value,
    ppf_exp_t exponent,
    ppf_context_t *ctx
);
