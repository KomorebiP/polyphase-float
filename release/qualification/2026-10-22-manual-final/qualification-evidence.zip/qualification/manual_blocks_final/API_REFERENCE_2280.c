int ppf_fits_uintmax_p(const ppf_t *op, ppf_rnd_t rnd);
