int ppf_asprintf(char **text, const char *format, ...);
