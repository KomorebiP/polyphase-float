int ppf_snprintf(char *buffer, size_t size, const char *format, ...);
