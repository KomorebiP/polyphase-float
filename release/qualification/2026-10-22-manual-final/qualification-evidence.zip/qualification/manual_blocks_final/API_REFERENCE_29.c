void *ppf_arena_alloc(ppf_context_t *ctx, size_t bytes, size_t alignment);
