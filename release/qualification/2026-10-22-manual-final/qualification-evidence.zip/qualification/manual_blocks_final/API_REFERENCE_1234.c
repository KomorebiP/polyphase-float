int ppf_zero_p(const ppf_t *x);
