int ppf_plan_product(
    ppf_product_plan_t *plan,
    const ppf_t *a,
    const ppf_t *b,
    ppf_product_operation_t operation,
    unsigned long workers
);
